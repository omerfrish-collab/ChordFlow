import com.chordflow.guitar.audio.ChordMath
import com.chordflow.guitar.audio.PitchMath
import com.chordflow.guitar.model.*
import com.chordflow.guitar.practice.*
import kotlin.math.*

fun toneChord(freqs: List<Double>, sr:Int=44100, n:Int=8192):FloatArray = FloatArray(n){i ->
    val t=i.toDouble()/sr
    (freqs.sumOf{sin(2*Math.PI*it*t)} / freqs.size).toFloat()
}

fun requireTrue(v:Boolean,msg:String){if(!v) error(msg)}
fun pitchWave(freq: Double, sr:Int=44100, n:Int=4096):ShortArray = ShortArray(n){i ->
    (sin(2*Math.PI*freq*i/sr)*12000).toInt().toShort()
}


fun main(){
    val chordTargets = linkedMapOf(
        "C" to listOf(261.63,329.63,392.00),
        "G" to listOf(196.00,246.94,293.66),
        "D" to listOf(146.83,185.00,220.00),
        "Am" to listOf(220.00,261.63,329.63),
        "Em" to listOf(164.81,196.00,246.94),
        "F" to listOf(174.61,220.00,261.63),
        "Dm" to listOf(146.83,174.61,220.00),
        "E7" to listOf(164.81,207.65,246.94,293.66),
        "A7" to listOf(220.00,277.18,329.63,392.00)
    )
    var correct = 0
    for ((expected, freqs) in chordTargets) {
        val guess = ChordMath.classify(ChordMath.chromaFromFrame(toneChord(freqs),44100))
        println("$expected -> $guess")
        if (guess.name == expected) correct++
    }
    requireTrue(correct == chordTargets.size, "Chord regression: $correct/${chordTargets.size}")

    val strings = linkedMapOf("E2" to 82.4069,"A2" to 110.0,"D3" to 146.832,"G3" to 195.998,"B3" to 246.942,"E4" to 329.628)
    for((expected,freq) in strings){
        val pitch=PitchMath.detect(pitchWave(freq),4096,44100) ?: error("No tuner pitch for $expected")
        requireTrue(pitch.note==expected,"Tuner expected $expected, got $pitch")
        requireTrue(kotlin.math.abs(pitch.cents)<1f,"Tuner cents $expected")
    }
    requireTrue(PitchMath.detect(ShortArray(4096),4096,44100)==null,"silence should return null")
    val plus12=440.0*Math.pow(2.0,12.0/1200.0)
    val detuned=PitchMath.detect(pitchWave(plus12),4096,44100) ?: error("No detuned A4")
    requireTrue(detuned.note=="A4" && kotlin.math.abs(detuned.cents-12f)<1.2f,"+12 cent A4")

    requireTrue(PracticeEngine.transpose("C",2)=="D","transpose C+2")
    requireTrue(PracticeEngine.transpose("F#m",-2)=="Em","transpose F#m-2")
    requireTrue(ChordLibrary.shapeFor("C")!=null,"C shape")
    requireTrue(ChordLibrary.shapeFor("F#")?.barreFret!=null,"F# barre")
    requireTrue(ChordLibrary.shapeFor("Bm")?.barreFret!=null,"Bm barre")

    val p=MusicianProfile(level=SkillLevel.BEGINNER,knownChords=setOf("C","G","Am","Em","D"),styles=setOf("Pop"),goals=setOf(Goal.SONGS))
    val segs=listOf(
        ChordSegment("C",0,1000),ChordSegment("G",1000,2000),ChordSegment("Am",2000,3000),ChordSegment("F",3000,4000),
        ChordSegment("C",4000,5000),ChordSegment("G",5000,6000)
    )
    val plan=PracticeEngine.build(p,segs)
    println("Plan: $plan")
    requireTrue(plan.transitions.isNotEmpty(),"transitions")
    requireTrue(plan.startBpm<plan.targetBpm,"bpm plan")
    requireTrue(plan.easyChords.isNotEmpty(),"easy chords")
    println("CORE TESTS PASSED: ${chordTargets.size}/${chordTargets.size} chords + 6/6 tuner strings")
}
