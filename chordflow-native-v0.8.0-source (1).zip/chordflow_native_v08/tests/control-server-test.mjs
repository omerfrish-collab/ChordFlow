import { spawn } from 'node:child_process';
import { mkdtemp, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

const dataDir = await mkdtemp(path.join(os.tmpdir(),'chordflow-control-'));
const port = 18891;
const ownerToken = 'test-owner-token-please-change';
const server = spawn(process.execPath,['control-server/server.mjs'],{
  cwd: process.cwd(),
  env:{...process.env,PORT:String(port),OWNER_TOKEN:ownerToken,DATA_DIR:dataDir},
  stdio:['ignore','pipe','pipe']
});

const base=`http://127.0.0.1:${port}`;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function waitReady(){
  for(let i=0;i<50;i++){
    try{ const r=await fetch(`${base}/health`); if(r.ok)return; }catch{}
    await sleep(100);
  }
  throw new Error('control server did not start');
}
async function json(url,opts={}){
  const r=await fetch(base+url,opts); const b=await r.json(); return {status:r.status,body:b};
}
const bearer=t=>({Authorization:`Bearer ${t}`,'Content-Type':'application/json'});

try{
  await waitReady();
  let r=await json('/v1/owner/verify',{method:'POST',headers:bearer(ownerToken)});
  if(r.status!==200) throw new Error('owner verify failed');
  r=await json('/v1/owner/verify',{method:'POST',headers:bearer('wrong')});
  if(r.status!==401) throw new Error('bad owner token accepted');

  r=await json('/v1/admin/invites',{method:'POST',headers:bearer(ownerToken),body:JSON.stringify({role:'ADMIN',label:'Admin test',expiresHours:1})});
  if(r.status!==200) throw new Error('owner admin invite failed');
  const adminCode=r.body.code;
  r=await json('/v1/auth/redeem',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:adminCode,deviceName:'Admin phone'})});
  if(r.status!==200 || r.body.role!=='ADMIN') throw new Error('admin redemption failed');
  const adminToken=r.body.token;

  const before=(await json('/v1/config')).body;
  r=await json('/v1/admin/config',{method:'POST',headers:bearer(adminToken),body:JSON.stringify({
    apkUrl:'https://evil.example/fake.apk',forceUpdate:true,
    features:{community:true},announcement:{id:'a',title:'hello',message:'allowed'}
  })});
  if(r.status!==200) throw new Error('admin safe config update failed');
  if(r.body.apkUrl!==before.apkUrl || r.body.forceUpdate!==before.forceUpdate) throw new Error('admin changed protected release fields');
  if(r.body.features.community!==true || r.body.announcement?.message!=='allowed') throw new Error('admin safe fields not applied');

  r=await json('/v1/admin/invites',{method:'POST',headers:bearer(adminToken),body:JSON.stringify({role:'ADMIN',label:'Escalate'})});
  if(r.status!==403) throw new Error('admin could create admin invite');

  r=await json('/v1/admin/config',{method:'POST',headers:bearer(ownerToken),body:JSON.stringify({latestVersionCode:9,latestVersionName:'0.9.0',apkUrl:'https://updates.example/ChordFlow.apk',forceUpdate:true})});
  if(r.status!==200 || r.body.latestVersionCode!==9 || r.body.apkUrl!=='https://updates.example/ChordFlow.apk' || r.body.forceUpdate!==true) throw new Error('owner release update failed');

  r=await json('/v1/admin/config',{method:'POST',headers:bearer(ownerToken),body:JSON.stringify({apkUrl:'http://not-secure.example/app.apk'})});
  if(r.status!==400) throw new Error('insecure APK URL accepted');
  r=await json('/v1/admin/config',{method:'POST',headers:bearer(ownerToken),body:JSON.stringify({apkSha256:'not-a-real-sha'})});
  if(r.status!==400) throw new Error('invalid APK SHA accepted');
  console.log('CONTROL SERVER TESTS PASSED');
} finally {
  server.kill('SIGTERM');
  await rm(dataDir,{recursive:true,force:true});
}
