# ChordFlow Control

Self-contained Node.js control service. No AI and no npm packages are required.

Environment:
- `OWNER_TOKEN`: long random secret known only to the owner.
- `PORT`: optional; defaults to 8787.

Public endpoint: `/v1/config`.
Owner endpoints require `Authorization: Bearer <OWNER_TOKEN>`.

Use HTTPS in production. Do not embed OWNER_TOKEN in a public APK. The owner enters it only on their own phone and it is stored locally there.
