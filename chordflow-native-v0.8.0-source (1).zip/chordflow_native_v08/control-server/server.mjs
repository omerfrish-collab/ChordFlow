import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const dir = path.dirname(fileURLToPath(import.meta.url));
const dataDir = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(dir, 'data');
fs.mkdirSync(dataDir,{recursive:true});
const configFile = path.join(dataDir, 'config.json');
const usersFile = path.join(dataDir, 'users.json');
const invitesFile = path.join(dataDir, 'invites.json');
const PORT = Number(process.env.PORT || 8787);
const OWNER_TOKEN = process.env.OWNER_TOKEN || '';

const defaultConfig = {
  minSupportedVersionCode: 8, latestVersionCode: 8, latestVersionName: '0.8.0',
  apkUrl: '', apkSha256: '', shareUrl: '', updateMessage: '', forceUpdate: false,
  features: { spotify: false, experimentalAnalyzer: true, community: false },
  announcement: null
};
for (const [file,value] of [[configFile,defaultConfig],[usersFile,[]],[invitesFile,[]]]) {
  if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(value,null,2));
}

const readJson = (f, fallback) => { try { return JSON.parse(fs.readFileSync(f,'utf8')); } catch { return fallback; } };
const writeJson = (f,v) => fs.writeFileSync(f, JSON.stringify(v,null,2));
const send = (res,status,obj) => { const b=JSON.stringify(obj); res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','content-length':Buffer.byteLength(b)}); res.end(b); };
const body = req => new Promise((resolve,reject)=>{ let s=''; req.on('data',d=>{s+=d;if(s.length>1_000_000)reject(new Error('body too large'));}); req.on('end',()=>{try{resolve(s?JSON.parse(s):{});}catch(e){reject(e);}}); });
const bearer = req => (req.headers.authorization||'').replace(/^Bearer\s+/i,'');
const owner = req => { const a=Buffer.from(bearer(req)); const b=Buffer.from(OWNER_TOKEN); return OWNER_TOKEN && a.length===b.length && crypto.timingSafeEqual(a,b); };
const hash = s => crypto.createHash('sha256').update(s).digest('hex');
const authUser = req => {
  if (owner(req)) return {id:'owner', role:'OWNER', label:'Owner'};
  const token=bearer(req); if(!token) return null;
  const users=readJson(usersFile,[]);
  return users.find(x=>x.tokenHash===hash(token)) || null;
};
const adminUser = req => { const u=authUser(req); return u && (u.role==='OWNER'||u.role==='ADMIN') ? u : null; };
const randomCode = () => crypto.randomBytes(6).toString('hex').toUpperCase();
const randomToken = () => crypto.randomBytes(32).toString('base64url');
const safeMerge = (base,patch) => ({...base,...patch,features:{...(base.features||{}),...(patch.features||{})}});

const server = http.createServer(async (req,res)=>{
  try {
    const u = new URL(req.url, `http://${req.headers.host}`);
    if (req.method==='GET' && u.pathname==='/health') return send(res,200,{ok:true});
    if (req.method==='GET' && u.pathname==='/v1/config') return send(res,200,readJson(configFile,{}));

    if (req.method==='POST' && u.pathname==='/v1/owner/verify') {
      if (!owner(req)) return send(res,401,{error:'invalid_owner_token'});
      return send(res,200,{ok:true,role:'OWNER'});
    }

    if (req.method==='POST' && u.pathname==='/v1/admin/config') {
      const actor=adminUser(req); if (!actor) return send(res,401,{error:'admin_required'});
      const incoming = await body(req);
      let patch;
      if (actor.role==='OWNER') {
        patch={...incoming};
        for (const key of ['latestVersionCode','minSupportedVersionCode']) {
          if (key in patch) patch[key]=Math.max(1,Number(patch[key])||1);
        }
        if ('apkUrl' in patch && patch.apkUrl && !String(patch.apkUrl).startsWith('https://')) return send(res,400,{error:'apk_url_must_use_https'});
        if ('apkSha256' in patch && patch.apkSha256 && !/^[a-fA-F0-9]{64}$/.test(String(patch.apkSha256))) return send(res,400,{error:'invalid_apk_sha256'});
        if ('shareUrl' in patch && patch.shareUrl && !String(patch.shareUrl).startsWith('https://')) return send(res,400,{error:'share_url_must_use_https'});
      } else {
        // Admins can operate the product, but only the Owner may redirect APK updates,
        // change minimum versions, or force an install.
        patch={};
        if ('announcement' in incoming) patch.announcement=incoming.announcement;
        if ('features' in incoming) patch.features=incoming.features;
      }
      const current=readJson(configFile,{}); const next=safeMerge(current,patch); writeJson(configFile,next); return send(res,200,next);
    }

    if (req.method==='POST' && u.pathname==='/v1/admin/invites') {
      const actor=adminUser(req); if (!actor) return send(res,401,{error:'admin_required'});
      const p=await body(req); const role=['ADMIN','TESTER','USER'].includes(p.role)?p.role:'USER';
      if(actor.role!=='OWNER' && role==='ADMIN') return send(res,403,{error:'owner_required_for_admin_invite'}); const hours=Math.min(720,Math.max(1,Number(p.expiresHours||72)));
      const invites=readJson(invitesFile,[]); const code=randomCode(); const item={id:crypto.randomUUID(),codeHash:hash(code),role,label:String(p.label||''),createdAt:Date.now(),expiresAt:Date.now()+hours*3600_000,used:false}; invites.push(item); writeJson(invitesFile,invites); return send(res,200,{code,role,expiresAt:item.expiresAt});
    }

    if (req.method==='POST' && u.pathname==='/v1/auth/redeem') {
      const p=await body(req); const code=String(p.code||'').trim().toUpperCase(); const invites=readJson(invitesFile,[]); const inv=invites.find(x=>!x.used&&x.expiresAt>Date.now()&&x.codeHash===hash(code)); if(!inv)return send(res,400,{error:'invalid_or_expired_invite'});
      inv.used=true; writeJson(invitesFile,invites); const raw=randomToken(); const users=readJson(usersFile,[]); const user={id:crypto.randomUUID(),role:inv.role,label:String(p.deviceName||inv.label||'Friend'),tokenHash:hash(raw),createdAt:Date.now(),lastSeenAt:Date.now()}; users.push(user); writeJson(usersFile,users); return send(res,200,{token:raw,role:user.role,userId:user.id});
    }

    if (req.method==='GET' && u.pathname==='/v1/me') {
      const token=bearer(req); const users=readJson(usersFile,[]); const user=users.find(x=>x.tokenHash===hash(token)); if(!user)return send(res,401,{error:'invalid_token'}); user.lastSeenAt=Date.now(); writeJson(usersFile,users); return send(res,200,{id:user.id,role:user.role,label:user.label});
    }

    if (req.method==='GET' && u.pathname==='/v1/admin/users') {
      if (!adminUser(req)) return send(res,401,{error:'admin_required'}); const users=readJson(usersFile,[]).map(({tokenHash,...x})=>x); return send(res,200,{users});
    }

    if (req.method==='POST' && /^\/v1\/admin\/users\/[^/]+\/role$/.test(u.pathname)) {
      const actor=adminUser(req); if (!actor) return send(res,401,{error:'admin_required'}); const userId=u.pathname.split('/')[4]; const p=await body(req); if(!['ADMIN','TESTER','USER'].includes(p.role))return send(res,400,{error:'invalid_role'});
      if(actor.role!=='OWNER' && p.role==='ADMIN') return send(res,403,{error:'owner_required_for_admin_role'}); const users=readJson(usersFile,[]); const user=users.find(x=>x.id===userId); if(!user)return send(res,404,{error:'not_found'}); user.role=p.role; writeJson(usersFile,users); return send(res,200,{ok:true,id:user.id,role:user.role});
    }

    return send(res,404,{error:'not_found'});
  } catch(e) { return send(res,500,{error:'server_error',message:e.message}); }
});

server.listen(PORT,()=>console.log(`ChordFlow Control listening on ${PORT}`));
