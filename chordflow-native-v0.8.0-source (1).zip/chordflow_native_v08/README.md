# ChordFlow Native Android

ChordFlow is an Android-first guitar practice app. The runtime does not require ChatGPT, Replit, Base44, Lovable, Gemini, OpenAI APIs, or any other AI service.

## Current native features

- Kotlin + Jetpack Compose Android app; no WebView/PWA shell.
- Local MP3/M4A/WAV import and on-device chord analysis.
- Built-in C–G–Am–F demo that exercises the player without copyrighted audio.
- Current/next chord, timestamped chord timeline and scrubbing.
- Tap a chord to open a small anchored fingering popover without dimming the player.
- Chord diagrams with X/O, finger numbers and cleaner barre shapes.
- Manual chord correction, transpose, 0.5x–1.25x playback speed and A/B loop.
- Personalized onboarding: level, styles, known chords and learning goal.
- Practice Studio: easier chord shapes, capo suggestion, strumming, fingerstyle, solo scale/exercise, transition trainer and direct transition loop.
- Transition trainer displays capo-adjusted shapes while looping the corresponding original-song passage.
- Metronome with Tap Tempo.
- Local microphone tuner using YIN pitch detection and adjustable A4 reference.
- Local song library.
- Owner/Admin/Tester/User control architecture.
- Owner activation verifies against the server; no manager password/token is hard-coded in the app.
- Optional control server for announcements, feature flags, invites, role management and update metadata.
- Owner-only release controls: version, minimum supported version, APK URL, checksum and forced-update flag.
- Update path supports HTTPS + SHA-256 verification before Android package installation.
- Spotify deliberately disabled for now and can be added later.

## Ownership and updates

The app is independent of AI at runtime. `control-server/` is ordinary Node.js code with no AI dependency.

Admins can manage safe product settings and users, but only the Owner can redirect APK updates or force an update. This prevents a delegated Admin from replacing the distributed Android package.

Android updates must always be signed with the same release signing key. Before wider distribution, create and securely back up one release keystore and configure CI secrets; never commit a release keystore or its password.

## Build

The project targets Android API 35 and minSdk 26. It uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21 and Gradle 8.10.2.

`.github/workflows/android-build.yml` builds an installable debug APK on GitHub-hosted Android tooling and uploads both the APK and its SHA-256. It also runs the control-server security/integration test before compiling Android.

## Control server

`control-server/server.mjs` supports a configurable persistent `DATA_DIR` and initializes clean storage automatically. It exposes:

- public app/update configuration
- Owner verification
- Admin/Tester/User invite redemption
- user role management
- announcements and feature flags
- Owner-protected release/update metadata

Use HTTPS in production. The Owner token belongs in a server environment variable and must never be embedded in the APK.
