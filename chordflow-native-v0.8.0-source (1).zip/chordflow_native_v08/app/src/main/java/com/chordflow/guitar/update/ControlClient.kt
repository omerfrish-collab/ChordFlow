package com.chordflow.guitar.update

import com.chordflow.guitar.model.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ControlClient(private val baseUrl: String, private val ownerToken: String = "") {
    data class InviteResult(val code: String, val role: UserRole, val expiresAt: Long)
    data class ManagedUser(val id: String, val role: UserRole, val label: String, val lastSeenAt: Long)
    data class AuthResult(val token: String, val role: UserRole, val userId: String)

    private fun connection(path: String): HttpURLConnection {
        require(baseUrl.startsWith("https://")) { "Control URL must use HTTPS" }
        return (URL("${baseUrl.trimEnd('/')}$path").openConnection() as HttpURLConnection).apply {
            connectTimeout = 6000
            readTimeout = 6000
        }
    }

    private fun readBody(con: HttpURLConnection): String {
        val stream = if (con.responseCode in 200..299) con.inputStream else con.errorStream
        return stream?.bufferedReader()?.use { it.readText() }.orEmpty()
    }

    fun fetchConfig(): RemoteConfig {
        val con = connection("/v1/config")
        val text = readBody(con)
        if (con.responseCode !in 200..299) error("Config ${con.responseCode}: $text")
        return parseConfig(JSONObject(text))
    }

    fun verifyOwner(): Boolean {
        require(ownerToken.isNotBlank()) { "Owner token not configured" }
        val con = connection("/v1/owner/verify")
        con.requestMethod = "POST"
        con.setRequestProperty("Authorization", "Bearer $ownerToken")
        readBody(con)
        return con.responseCode in 200..299
    }

    fun updateConfig(patch: JSONObject): Boolean {
        require(ownerToken.isNotBlank()) { "Owner token not configured" }
        val con = connection("/v1/admin/config")
        con.requestMethod = "POST"
        con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json")
        con.setRequestProperty("Authorization", "Bearer $ownerToken")
        con.outputStream.use { it.write(patch.toString().toByteArray()) }
        readBody(con)
        return con.responseCode in 200..299
    }

    fun createInvite(role: UserRole, label: String, expiresHours: Int = 72): InviteResult {
        require(ownerToken.isNotBlank()) { "Owner token not configured" }
        require(role != UserRole.OWNER) { "Owner invites are not allowed" }
        val con = connection("/v1/admin/invites")
        con.requestMethod = "POST"
        con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json")
        con.setRequestProperty("Authorization", "Bearer $ownerToken")
        val payload = JSONObject()
            .put("role", role.name)
            .put("label", label)
            .put("expiresHours", expiresHours.coerceIn(1, 720))
        con.outputStream.use { it.write(payload.toString().toByteArray()) }
        val text = readBody(con)
        if (con.responseCode !in 200..299) error("Invite ${con.responseCode}: $text")
        val o = JSONObject(text)
        return InviteResult(
            code = o.getString("code"),
            role = UserRole.valueOf(o.getString("role")),
            expiresAt = o.optLong("expiresAt")
        )
    }

    fun listUsers(): List<ManagedUser> {
        require(ownerToken.isNotBlank()) { "Owner token not configured" }
        val con = connection("/v1/admin/users")
        con.setRequestProperty("Authorization", "Bearer $ownerToken")
        val text = readBody(con)
        if (con.responseCode !in 200..299) error("Users ${con.responseCode}: $text")
        val arr = JSONObject(text).optJSONArray("users") ?: return emptyList()
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ManagedUser(
                id = o.getString("id"),
                role = runCatching { UserRole.valueOf(o.optString("role", "USER")) }.getOrDefault(UserRole.USER),
                label = o.optString("label", "User"),
                lastSeenAt = o.optLong("lastSeenAt")
            )
        }
    }

    fun setUserRole(userId: String, role: UserRole): Boolean {
        require(ownerToken.isNotBlank()) { "Owner token not configured" }
        require(role != UserRole.OWNER) { "Owner role cannot be assigned remotely" }
        val con = connection("/v1/admin/users/$userId/role")
        con.requestMethod = "POST"
        con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json")
        con.setRequestProperty("Authorization", "Bearer $ownerToken")
        con.outputStream.use { it.write(JSONObject().put("role", role.name).toString().toByteArray()) }
        readBody(con)
        return con.responseCode in 200..299
    }

    fun redeemInvite(code: String, deviceName: String = "Android"): AuthResult {
        val con = connection("/v1/auth/redeem")
        con.requestMethod = "POST"
        con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json")
        val payload = JSONObject().put("code", code.trim()).put("deviceName", deviceName)
        con.outputStream.use { it.write(payload.toString().toByteArray()) }
        val text = readBody(con)
        if (con.responseCode !in 200..299) error("Invite code rejected")
        val o = JSONObject(text)
        return AuthResult(o.getString("token"), UserRole.valueOf(o.getString("role")), o.getString("userId"))
    }

    fun fetchMe(userToken: String): UserRole {
        require(userToken.isNotBlank()) { "User token not configured" }
        val con = connection("/v1/me")
        con.setRequestProperty("Authorization", "Bearer $userToken")
        val text = readBody(con)
        if (con.responseCode !in 200..299) error("Session expired")
        return UserRole.valueOf(JSONObject(text).optString("role", "USER"))
    }

    companion object {
        fun parseConfig(o: JSONObject): RemoteConfig {
            val f = o.optJSONObject("features") ?: JSONObject()
            val a = o.optJSONObject("announcement")
            return RemoteConfig(
                minSupportedVersionCode = o.optInt("minSupportedVersionCode", 1),
                latestVersionCode = o.optInt("latestVersionCode", 1),
                latestVersionName = o.optString("latestVersionName", ""),
                apkUrl = o.optString("apkUrl", ""),
                apkSha256 = o.optString("apkSha256", ""),
                shareUrl = o.optString("shareUrl", ""),
                updateMessage = o.optString("updateMessage", ""),
                forceUpdate = o.optBoolean("forceUpdate", false),
                features = FeatureFlags(
                    f.optBoolean("spotify"),
                    f.optBoolean("experimentalAnalyzer", true),
                    f.optBoolean("community")
                ),
                announcement = a?.let { AppAnnouncement(it.optString("id"), it.optString("title"), it.optString("message")) }
            )
        }
    }
}
