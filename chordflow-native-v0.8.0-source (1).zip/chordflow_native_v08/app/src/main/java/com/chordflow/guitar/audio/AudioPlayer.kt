package com.chordflow.guitar.audio

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri

class AudioPlayer(private val context: Context) {
    private var player: MediaPlayer? = null
    var loopA: Int? = null
    var loopB: Int? = null

    fun load(uri: Uri, onReady: (Int) -> Unit = {}) {
        release()
        player = MediaPlayer().apply {
            setDataSource(context, uri)
            setOnPreparedListener { onReady(duration) }
            prepareAsync()
        }
    }

    fun play() { player?.start() }
    fun pause() { player?.pause() }
    fun toggle() { player?.let { if (it.isPlaying) it.pause() else it.start() } }
    fun seek(ms: Int) { player?.seekTo(ms.coerceAtLeast(0)) }
    fun position(): Int = player?.currentPosition ?: 0
    fun duration(): Int = player?.duration ?: 0
    fun isPlaying(): Boolean = player?.isPlaying == true
    fun speed(value: Float) {
        player?.let { p ->
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                runCatching { p.playbackParams = p.playbackParams.setSpeed(value.coerceIn(0.5f, 1.25f)) }
            }
        }
    }

    fun tickLoop() {
        val p = player ?: return
        val a = loopA; val b = loopB
        if (a != null && b != null && b > a && p.currentPosition >= b) p.seekTo(a)
    }

    fun release() { player?.release(); player = null }
}
