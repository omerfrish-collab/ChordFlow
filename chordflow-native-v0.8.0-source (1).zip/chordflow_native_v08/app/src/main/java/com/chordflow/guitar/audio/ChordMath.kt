package com.chordflow.guitar.audio

import kotlin.math.*

data class ChordGuess(val name: String, val confidence: Float)

object ChordMath {
    private val notes = listOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B")

    fun chromaFromFrame(frame: FloatArray, sampleRate: Int): FloatArray {
        val n = nextPow2(frame.size)
        val re = DoubleArray(n)
        val im = DoubleArray(n)
        for (i in frame.indices) {
            val w = 0.5 - 0.5 * cos(2.0 * Math.PI * i / max(1, frame.size - 1))
            re[i] = frame[i] * w
        }
        fft(re, im)
        val chroma = DoubleArray(12)
        val bass = DoubleArray(12)
        val half = n / 2
        for (k in 1 until half) {
            val f = k.toDouble() * sampleRate / n
            if (f < 55.0 || f > 5000.0) continue
            val mag = hypot(re[k], im[k])
            if (mag <= 0) continue
            val midi = 69.0 + 12.0 * (ln(f / 440.0) / ln(2.0))
            val pc = ((round(midi).toInt() % 12) + 12) % 12
            chroma[pc] += mag
            if (f < 300.0) bass[pc] += mag
        }
        val sum = chroma.sum().coerceAtLeast(1e-12)
        return FloatArray(12) { i -> ((chroma[i] / sum) * 0.82 + (bass[i] / bass.sum().coerceAtLeast(1e-12)) * 0.18).toFloat() }
    }

    fun classify(chroma: FloatArray): ChordGuess {
        if (chroma.sum() < 1e-5f) return ChordGuess("N.C.", 1f)
        var best = "N.C."
        var bestScore = Double.NEGATIVE_INFINITY
        var second = Double.NEGATIVE_INFINITY
        for (root in 0 until 12) {
            val candidates = listOf(
                "${notes[root]}" to intArrayOf(root, (root+4)%12, (root+7)%12),
                "${notes[root]}m" to intArrayOf(root, (root+3)%12, (root+7)%12),
                "${notes[root]}7" to intArrayOf(root, (root+4)%12, (root+7)%12, (root+10)%12)
            )
            for ((name, tones) in candidates) {
                var inScore = 0.0
                var outScore = 0.0
                for (i in 0 until 12) {
                    if (i in tones) inScore += chroma[i] else outScore += chroma[i]
                }
                val rootBonus = chroma[root] * 0.18
                // Use total template coverage instead of the average. Averaging by tone count
                // unfairly penalizes real dominant-7 chords and made strong A7/E7 recordings
                // collapse to their major triads. The modest complexity penalty keeps plain
                // triads preferred when the seventh is not actually present.
                val complexityPenalty = if (tones.size > 3) 0.045 else 0.0
                val score = inScore - outScore * 0.45 + rootBonus - complexityPenalty
                if (score > bestScore) { second = bestScore; bestScore = score; best = name }
                else if (score > second) second = score
            }
        }
        val margin = (bestScore - second).coerceAtLeast(0.0)
        val confidence = (0.45 + margin * 1.7).coerceIn(0.0, 0.98).toFloat()
        return ChordGuess(best, confidence)
    }

    fun rms(frame: FloatArray): Float {
        if (frame.isEmpty()) return 0f
        var s = 0.0
        for (v in frame) s += v * v
        return sqrt(s / frame.size).toFloat()
    }

    private fun nextPow2(v: Int): Int {
        var n = 1
        while (n < v) n = n shl 1
        return n
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * Math.PI / len
            val wlenR = cos(ang); val wlenI = sin(ang)
            var i = 0
            while (i < n) {
                var wr = 1.0; var wi = 0.0
                for (k in 0 until len/2) {
                    val uR = re[i+k]; val uI = im[i+k]
                    val vR = re[i+k+len/2]*wr - im[i+k+len/2]*wi
                    val vI = re[i+k+len/2]*wi + im[i+k+len/2]*wr
                    re[i+k] = uR + vR; im[i+k] = uI + vI
                    re[i+k+len/2] = uR - vR; im[i+k+len/2] = uI - vI
                    val nwr = wr*wlenR - wi*wlenI
                    wi = wr*wlenI + wi*wlenR
                    wr = nwr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
