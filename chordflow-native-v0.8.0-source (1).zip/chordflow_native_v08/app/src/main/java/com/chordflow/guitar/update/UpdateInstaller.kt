package com.chordflow.guitar.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class UpdateInstaller(private val context: Context) {
    data class DownloadedApk(val uri: Uri, val sha256: String, val bytes: Long)

    suspend fun downloadVerifiedApk(
        url: String,
        versionName: String,
        expectedSha256: String = "",
        onProgress: (Float) -> Unit = {}
    ): DownloadedApk = withContext(Dispatchers.IO) {
        require(url.startsWith("https://")) { "APK URL must use HTTPS" }
        val con = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 20_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "ChordFlow-Android")
        }
        try {
            require(con.responseCode in 200..299) { "Update download failed (${con.responseCode})" }
            val total = con.contentLengthLong
            val safeName = versionName.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val outFile = File(context.cacheDir, "ChordFlow-$safeName.apk")
            val digest = MessageDigest.getInstance("SHA-256")
            var written = 0L
            con.inputStream.use { input ->
                outFile.outputStream().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        output.write(buffer, 0, n)
                        digest.update(buffer, 0, n)
                        written += n
                        if (total > 0) onProgress((written.toDouble() / total).toFloat().coerceIn(0f, 1f))
                    }
                }
            }
            val actual = digest.digest().joinToString("") { "%02x".format(it) }
            val expected = expectedSha256.trim().lowercase()
            if (expected.isNotBlank() && !actual.equals(expected, ignoreCase = true)) {
                outFile.delete()
                error("Update verification failed")
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", outFile)
            onProgress(1f)
            DownloadedApk(uri, actual, written)
        } finally {
            con.disconnect()
        }
    }

    fun canInstallPackages(): Boolean = if (android.os.Build.VERSION.SDK_INT >= 26) context.packageManager.canRequestPackageInstalls() else true

    fun openInstallPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            context.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}")))
        }
    }

    fun launchInstaller(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
