package com.chordflow.guitar.data

import android.content.Context
import com.chordflow.guitar.model.*
import org.json.JSONArray
import org.json.JSONObject

class AppPreferences(context: Context) {
    private val sp = context.getSharedPreferences("chordflow", Context.MODE_PRIVATE)

    fun saveProfile(p: MusicianProfile) {
        val o = JSONObject()
        o.put("name", p.name)
        o.put("level", p.level.name)
        o.put("styles", JSONArray(p.styles.toList()))
        o.put("knownChords", JSONArray(p.knownChords.toList()))
        o.put("goals", JSONArray(p.goals.map { it.name }))
        o.put("language", p.language)
        sp.edit().putString("profile", o.toString()).apply()
    }

    fun loadProfile(): MusicianProfile? {
        val s = sp.getString("profile", null) ?: return null
        return runCatching {
            val o = JSONObject(s)
            MusicianProfile(
                name = o.optString("name"),
                level = SkillLevel.valueOf(o.optString("level", SkillLevel.BEGINNER.name)),
                styles = o.optJSONArray("styles").toSet(),
                knownChords = o.optJSONArray("knownChords").toSet(),
                goals = o.optJSONArray("goals").toList().map { Goal.valueOf(it) }.toSet(),
                language = o.optString("language", "he")
            )
        }.getOrNull()
    }

    fun setRole(role: UserRole) = sp.edit().putString("role", role.name).apply()
    fun getRole(): UserRole = runCatching { UserRole.valueOf(sp.getString("role", UserRole.USER.name)!!) }.getOrDefault(UserRole.USER)

    fun setControlUrl(url: String) = sp.edit().putString("controlUrl", url.trimEnd('/')).apply()
    fun getControlUrl(): String = sp.getString("controlUrl", "") ?: ""
    fun setOwnerToken(token: String) = sp.edit().putString("ownerToken", token).apply()
    fun getOwnerToken(): String = sp.getString("ownerToken", "") ?: ""
    fun setUserToken(token: String) = sp.edit().putString("userToken", token).apply()
    fun getUserToken(): String = sp.getString("userToken", "") ?: ""
    fun clearAll() = sp.edit().clear().apply()

    private fun JSONArray?.toSet(): Set<String> = this?.let { a -> (0 until a.length()).map { a.optString(it) }.toSet() } ?: emptySet()
    private fun JSONArray?.toList(): List<String> = this?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: emptyList()
}
