package com.chordflow.guitar.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.chordflow.guitar.model.ChordSegment
import java.nio.ByteOrder
import kotlin.math.max

class ChordAnalyzer(private val context: Context) {
    data class Result(val durationMs: Long, val segments: List<ChordSegment>)

    fun analyze(uri: Uri, onProgress: (Float) -> Unit = {}): Result {
        val decoded = decodeMonoPcm(uri)
        val samples = decoded.first
        val sampleRate = decoded.second
        if (samples.isEmpty()) return Result(0, emptyList())
        val durationMs = samples.size * 1000L / sampleRate
        val frameSize = 4096
        val hop = 2048
        val energies = mutableListOf<Float>()
        var pos = 0
        while (pos + frameSize <= samples.size) {
            energies += ChordMath.rms(samples.copyOfRange(pos, pos + frameSize))
            pos += hop
        }
        val sorted = energies.sorted()
        val median = if (sorted.isEmpty()) 0f else sorted[sorted.size/2]
        val silenceThreshold = max(0.0025f, median * 0.18f)

        val raw = mutableListOf<ChordSegment>()
        pos = 0
        var idx = 0
        while (pos + frameSize <= samples.size) {
            val frame = samples.copyOfRange(pos, pos + frameSize)
            val rms = ChordMath.rms(frame)
            val guess = if (rms < silenceThreshold) ChordGuess("N.C.", 0.98f)
            else ChordMath.classify(ChordMath.chromaFromFrame(frame, sampleRate))
            val start = pos * 1000L / sampleRate
            val end = (pos + hop) * 1000L / sampleRate
            raw += ChordSegment(guess.name, start, end, guess.confidence)
            pos += hop; idx++
            if (idx % 8 == 0) onProgress(pos.toFloat() / samples.size)
        }
        onProgress(1f)
        return Result(durationMs, smoothAndMerge(raw))
    }

    private fun smoothAndMerge(raw: List<ChordSegment>): List<ChordSegment> {
        if (raw.isEmpty()) return raw
        val names = raw.map { it.chord }.toMutableList()
        for (i in 1 until names.lastIndex) {
            if (names[i-1] == names[i+1] && names[i] != names[i-1]) names[i] = names[i-1]
        }
        val merged = mutableListOf<ChordSegment>()
        var curName = names[0]
        var start = raw[0].startMs
        var end = raw[0].endMs
        var confSum = raw[0].confidence
        var count = 1
        for (i in 1 until raw.size) {
            if (names[i] == curName) {
                end = raw[i].endMs; confSum += raw[i].confidence; count++
            } else {
                merged += ChordSegment(curName, start, end, confSum/count)
                curName = names[i]; start = raw[i].startMs; end = raw[i].endMs; confSum = raw[i].confidence; count = 1
            }
        }
        merged += ChordSegment(curName, start, end, confSum/count)

        // Don't simply drop very short detections because that creates holes in the
        // timeline. Fold them into the previous stable segment instead.
        val stable = mutableListOf<ChordSegment>()
        for (seg in merged) {
            if (seg.endMs - seg.startMs < 180 && stable.isNotEmpty()) {
                val prev = stable.removeAt(stable.lastIndex)
                stable += prev.copy(endMs = seg.endMs, confidence = (prev.confidence + seg.confidence) / 2f)
            } else stable += seg
        }
        return stable
    }

    private fun decodeMonoPcm(uri: Uri): Pair<FloatArray, Int> {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                extractor.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            } ?: error("Cannot open audio")
            var trackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) { trackIndex = i; format = f; break }
            }
            require(trackIndex >= 0 && format != null) { "No audio track" }
            extractor.selectTrack(trackIndex)
            val mime = format!!.getString(MediaFormat.KEY_MIME)!!
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()
            val sampleRate = format!!.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channels = format!!.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val pcm = FloatArrayBuilder(sampleRate * 60)
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            while (!outputDone) {
                if (!inputDone) {
                    val inIndex = codec.dequeueInputBuffer(10_000)
                    if (inIndex >= 0) {
                        val buf = codec.getInputBuffer(inIndex)!!
                        val size = extractor.readSampleData(buf, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIndex = codec.dequeueOutputBuffer(info, 10_000)
                if (outIndex >= 0) {
                    val out = codec.getOutputBuffer(outIndex)!!
                    out.order(ByteOrder.LITTLE_ENDIAN)
                    val shorts = out.asShortBuffer()
                    val frames = shorts.remaining() / max(1, channels)
                    repeat(frames) {
                        var sum = 0f
                        repeat(channels) { sum += shorts.get() / 32768f }
                        pcm.add(sum / channels)
                    }
                    outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    codec.releaseOutputBuffer(outIndex, false)
                }
            }
            return pcm.toFloatArray() to sampleRate
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    private class FloatArrayBuilder(initialCapacity: Int) {
        private var data = FloatArray(initialCapacity.coerceAtLeast(1024))
        private var size = 0
        fun add(value: Float) {
            if (size == data.size) data = data.copyOf((data.size * 3 / 2).coerceAtLeast(data.size + 1024))
            data[size++] = value
        }
        fun toFloatArray(): FloatArray = data.copyOf(size)
    }
}
