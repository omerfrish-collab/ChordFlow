package com.chordflow.guitar.model

enum class SkillLevel { BEGINNER, INTERMEDIATE, ADVANCED }
enum class Goal { SONGS, STRUMMING, FINGERSTYLE, SOLOS }
enum class UserRole { OWNER, ADMIN, TESTER, USER }

data class MusicianProfile(
    val name: String = "",
    val level: SkillLevel = SkillLevel.BEGINNER,
    val styles: Set<String> = setOf("Pop"),
    val knownChords: Set<String> = setOf("C", "G", "Am", "Em", "D"),
    val goals: Set<Goal> = setOf(Goal.SONGS),
    val language: String = "he"
)

data class ChordSegment(
    val chord: String,
    val startMs: Long,
    val endMs: Long,
    val confidence: Float = 0.7f
)

data class Song(
    val id: String,
    val title: String,
    val artist: String = "",
    val uri: String = "",
    val durationMs: Long = 0,
    val chords: List<ChordSegment> = emptyList(),
    val savedAt: Long = System.currentTimeMillis()
)

data class ChordShape(
    val chord: String,
    val frets: List<Int?>,
    val fingers: List<Int?>,
    val barreFret: Int? = null,
    val barreFromString: Int? = null,
    val barreToString: Int? = null,
    val baseFret: Int = 1
)

data class PracticePlan(
    val easyChords: List<String>,
    val capo: Int,
    val strumming: String,
    val fingerstyle: String,
    val soloScale: String,
    val soloExercise: String,
    val startBpm: Int,
    val targetBpm: Int,
    val transitions: List<Pair<String, String>>
)

data class FeatureFlags(
    val spotify: Boolean = false,
    val experimentalAnalyzer: Boolean = true,
    val community: Boolean = false
)

data class AppAnnouncement(
    val id: String = "",
    val title: String = "",
    val message: String = ""
)

data class RemoteConfig(
    val minSupportedVersionCode: Int = 1,
    val latestVersionCode: Int = 8,
    val latestVersionName: String = "0.8.0",
    val apkUrl: String = "",
    val apkSha256: String = "",
    val shareUrl: String = "",
    val updateMessage: String = "",
    val forceUpdate: Boolean = false,
    val features: FeatureFlags = FeatureFlags(),
    val announcement: AppAnnouncement? = null
)
