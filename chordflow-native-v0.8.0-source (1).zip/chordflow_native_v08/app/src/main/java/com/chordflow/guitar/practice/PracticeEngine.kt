package com.chordflow.guitar.practice

import com.chordflow.guitar.model.*

object PracticeEngine {
    private val easy = setOf("C","G","D","A","E","Am","Em","Dm")

    fun build(profile: MusicianProfile, chords: List<ChordSegment>): PracticePlan {
        val unique = chords.map { it.chord }.filter { it != "N.C." }.distinct()
        val capoChoice = findBestCapo(unique, profile.knownChords)
        val simplified = unique.map { simplify(transpose(it, -capoChoice)) }
        val style = profile.styles.firstOrNull() ?: "Pop"
        val start = when(profile.level) { SkillLevel.BEGINNER -> 55; SkillLevel.INTERMEDIATE -> 75; SkillLevel.ADVANCED -> 95 }
        val target = start + when(profile.level) { SkillLevel.BEGINNER -> 20; SkillLevel.INTERMEDIATE -> 35; SkillLevel.ADVANCED -> 50 }
        val transitions = chords.windowed(2).map { it[0].chord to it[1].chord }.filter { it.first != it.second && it.first != "N.C." && it.second != "N.C." }
            .groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(5).map { it.key }
        return PracticePlan(
            easyChords = simplified,
            capo = capoChoice,
            strumming = when(style.lowercase()) { "rock" -> "↓ ↓↑ ↑↓↑"; "folk" -> "↓ ↓↑ ↓↑"; else -> "↓ ↓↑ ↑↓↑" },
            fingerstyle = when(profile.level) { SkillLevel.BEGINNER -> "P–i–m–a"; SkillLevel.INTERMEDIATE -> "P–i–m–a–m–i"; SkillLevel.ADVANCED -> "P–i–m–a–m–i + bass variation" },
            soloScale = inferScale(unique),
            soloExercise = when(profile.level) { SkillLevel.BEGINNER -> "4-note call & response"; SkillLevel.INTERMEDIATE -> "8-bar pentatonic phrase with slides"; SkillLevel.ADVANCED -> "8-bar phrase with slides, bends and chord tones" },
            startBpm = start,
            targetBpm = target,
            transitions = transitions
        )
    }

    fun simplify(chord: String): String = when {
        chord.endsWith("maj7") -> chord.removeSuffix("maj7")
        chord.endsWith("7") && !chord.endsWith("m7") -> chord.removeSuffix("7")
        chord.endsWith("m7") -> chord.removeSuffix("7")
        else -> chord
    }

    fun transpose(chord: String, semitones: Int): String {
        val roots = listOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B")
        val root = roots.firstOrNull { chord.startsWith(it) && (it.length == 2 || chord.getOrNull(1) != '#') } ?: return chord
        val suffix = chord.removePrefix(root)
        val idx = roots.indexOf(root)
        val n = ((idx + semitones) % 12 + 12) % 12
        return roots[n] + suffix
    }

    private fun findBestCapo(chords: List<String>, known: Set<String>): Int {
        var best = 0; var bestScore = -1
        for (capo in 0..7) {
            val score = chords.count { transpose(it, -capo) in known || simplify(transpose(it,-capo)) in easy }
            if (score > bestScore) { bestScore = score; best = capo }
        }
        return best
    }

    private fun inferScale(chords: List<String>): String {
        val first = chords.firstOrNull()?.removeSuffix("m")?.removeSuffix("7") ?: "C"
        return if (chords.any { it == first + "m" }) "$first minor pentatonic" else "$first major / relative minor"
    }
}
