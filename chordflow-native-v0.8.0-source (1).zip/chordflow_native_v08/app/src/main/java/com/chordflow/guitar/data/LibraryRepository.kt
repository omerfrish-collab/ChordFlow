package com.chordflow.guitar.data

import android.content.Context
import com.chordflow.guitar.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class LibraryRepository(context: Context) {
    private val file = File(context.filesDir, "songs.json")

    fun load(): List<Song> {
        if (!file.exists()) return emptyList()
        return runCatching {
            val a = JSONArray(file.readText())
            (0 until a.length()).map { decode(a.getJSONObject(it)) }
        }.getOrDefault(emptyList())
    }

    fun save(song: Song) {
        val list = load().toMutableList()
        val i = list.indexOfFirst { it.id == song.id }
        if (i >= 0) list[i] = song else list.add(0, song)
        write(list)
    }

    fun delete(id: String) = write(load().filterNot { it.id == id })
    fun clear() { if (file.exists()) file.delete() }
    fun newId(): String = UUID.randomUUID().toString()

    private fun write(list: List<Song>) {
        val a = JSONArray(); list.forEach { a.put(encode(it)) }; file.writeText(a.toString())
    }

    private fun encode(s: Song): JSONObject = JSONObject().apply {
        put("id", s.id); put("title", s.title); put("artist", s.artist); put("uri", s.uri)
        put("durationMs", s.durationMs); put("savedAt", s.savedAt)
        put("chords", JSONArray().apply { s.chords.forEach { c -> put(JSONObject().apply {
            put("chord", c.chord); put("startMs", c.startMs); put("endMs", c.endMs); put("confidence", c.confidence)
        }) } })
    }

    private fun decode(o: JSONObject): Song {
        val a = o.optJSONArray("chords") ?: JSONArray()
        val chords = (0 until a.length()).map { i ->
            a.getJSONObject(i).let { ChordSegment(it.optString("chord"), it.optLong("startMs"), it.optLong("endMs"), it.optDouble("confidence", .7).toFloat()) }
        }
        return Song(o.optString("id"), o.optString("title"), o.optString("artist"), o.optString("uri"), o.optLong("durationMs"), chords, o.optLong("savedAt"))
    }
}
