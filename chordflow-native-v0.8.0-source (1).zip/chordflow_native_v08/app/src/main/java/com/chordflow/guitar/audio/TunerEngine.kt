package com.chordflow.guitar.audio

import android.Manifest
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.annotation.RequiresPermission

class TunerEngine {
    data class Pitch(val hz: Float, val note: String, val cents: Float, val confidence: Float = 0f)
    private var record: AudioRecord? = null
    @Volatile private var running = false

    @RequiresPermission(Manifest.permission.RECORD_AUDIO)
    fun start(a4: Float = 440f, onPitch: (Pitch?) -> Unit) {
        if (running) return
        val sr = 44100
        val size = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(4096)
        record = AudioRecord(MediaRecorder.AudioSource.DEFAULT, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size * 2)
        running = true
        record!!.startRecording()
        Thread({
            val buf = ShortArray(4096)
            while (running) {
                val n = record?.read(buf, 0, buf.size) ?: 0
                if (n > 0) onPitch(detect(buf, n, sr, a4))
            }
        }, "ChordFlow-Tuner").apply { isDaemon = true }.start()
    }

    fun stop() {
        running = false
        try { record?.stop() } catch (_: Exception) {}
        record?.release(); record = null
    }

    fun detect(samples: ShortArray, n: Int, sampleRate: Int, a4: Float = 440f): Pitch? =
        PitchMath.detect(samples, n, sampleRate, a4)?.let { Pitch(it.hz, it.note, it.cents, it.confidence) }
}
