package com.chordflow.guitar.practice

import com.chordflow.guitar.model.ChordShape

object ChordLibrary {
    private val openShapes = mapOf(
        "C" to ChordShape("C", listOf(null,3,2,0,1,0), listOf(null,3,2,null,1,null)),
        "G" to ChordShape("G", listOf(3,2,0,0,0,3), listOf(2,1,null,null,null,3)),
        "D" to ChordShape("D", listOf(null,null,0,2,3,2), listOf(null,null,null,1,3,2)),
        "A" to ChordShape("A", listOf(null,0,2,2,2,0), listOf(null,null,1,2,3,null)),
        "E" to ChordShape("E", listOf(0,2,2,1,0,0), listOf(null,2,3,1,null,null)),
        "Am" to ChordShape("Am", listOf(null,0,2,2,1,0), listOf(null,null,2,3,1,null)),
        "Em" to ChordShape("Em", listOf(0,2,2,0,0,0), listOf(null,2,3,null,null,null)),
        "Dm" to ChordShape("Dm", listOf(null,null,0,2,3,1), listOf(null,null,null,2,3,1)),
        "A7" to ChordShape("A7", listOf(null,0,2,0,2,0), listOf(null,null,2,null,3,null)),
        "D7" to ChordShape("D7", listOf(null,null,0,2,1,2), listOf(null,null,null,2,1,3)),
        "E7" to ChordShape("E7", listOf(0,2,0,1,0,0), listOf(null,2,null,1,null,null)),
        "G7" to ChordShape("G7", listOf(3,2,0,0,0,1), listOf(3,2,null,null,null,1)),
        "C7" to ChordShape("C7", listOf(null,3,2,3,1,0), listOf(null,3,2,4,1,null)),
        "B7" to ChordShape("B7", listOf(null,2,1,2,0,2), listOf(null,2,1,3,null,4)),
        "F" to ChordShape("F", listOf(1,3,3,2,1,1), listOf(1,3,4,2,1,1), 1, 6, 1, 1),
        "Bm" to ChordShape("Bm", listOf(null,2,4,4,3,2), listOf(null,1,3,4,2,1), 2, 5, 1, 2),
        "F#m" to ChordShape("F#m", listOf(2,4,4,2,2,2), listOf(1,3,4,1,1,1), 2, 6, 1, 2),
        "C#m" to ChordShape("C#m", listOf(null,4,6,6,5,4), listOf(null,1,3,4,2,1), 4, 5, 1, 4),
        "G#m" to ChordShape("G#m", listOf(4,6,6,4,4,4), listOf(1,3,4,1,1,1), 4, 6, 1, 4)
    )

    fun shapeFor(chord: String): ChordShape? {
        openShapes[chord]?.let { return it }
        return movableShape(chord)
    }

    private fun movableShape(chord: String): ChordShape? {
        val roots = listOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B")
        val minor = chord.endsWith("m") && !chord.endsWith("maj")
        val dominant7 = chord.endsWith("7") && !chord.contains("maj7")
        val root = chord.removeSuffix("m").removeSuffix("7")
        val index = roots.indexOf(root)
        if (index < 0) return null
        val eIndex = roots.indexOf("E")
        val fret = (index - eIndex + 12) % 12
        val base = if (fret == 0) 12 else fret
        return when {
            minor -> ChordShape(chord, listOf(base,base+2,base+2,base,base,base), listOf(1,3,4,1,1,1), base, 6, 1, base)
            dominant7 -> ChordShape(chord, listOf(base,base+2,base,base+1,base,base), listOf(1,3,1,2,1,1), base, 6, 1, base)
            else -> ChordShape(chord, listOf(base,base+2,base+2,base+1,base,base), listOf(1,3,4,2,1,1), base, 6, 1, base)
        }
    }
}
