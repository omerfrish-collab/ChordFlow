@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.chordflow.guitar.ui

import android.Manifest
import android.net.Uri
import android.content.Intent
import android.content.ClipData
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.chordflow.guitar.audio.*
import com.chordflow.guitar.data.*
import com.chordflow.guitar.model.*
import com.chordflow.guitar.practice.*
import com.chordflow.guitar.update.*
import kotlinx.coroutines.*
import org.json.JSONObject

private val Bg = Color(0xFF0B0F14)
private val CardBg = Color(0xFF121923)
private val Green = Color(0xFF5CDD8B)
private val Muted = Color(0xFF92A0AF)

enum class Screen { HOME, LIBRARY, PLAYER, PRACTICE, TUNER, SETTINGS, ADMIN }

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun ChordFlowApp() {
    val context = LocalContext.current
    val prefs = remember { AppPreferences(context) }
    val library = remember { LibraryRepository(context) }
    var profile by remember { mutableStateOf(prefs.loadProfile()) }
    var role by remember { mutableStateOf(prefs.getRole()) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var songs by remember { mutableStateOf(library.load()) }
    var currentSong by remember { mutableStateOf<Song?>(null) }
    var pendingLoop by remember { mutableStateOf<Pair<Int,Int>?>(null) }
    var analyzing by remember { mutableStateOf(false) }
    var analyzeError by remember { mutableStateOf("") }
    var analyzeProgress by remember { mutableFloatStateOf(0f) }
    var remoteConfig by remember { mutableStateOf<RemoteConfig?>(null) }
    var remoteError by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(profile, prefs.getControlUrl()) {
        val url = prefs.getControlUrl()
        if (profile != null && url.startsWith("https://")) {
            runCatching { withContext(Dispatchers.IO) { ControlClient(url).fetchConfig() } }
                .onSuccess { remoteConfig = it; remoteError = "" }
                .onFailure { remoteError = it.message.orEmpty() }
        }
    }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            analyzing = true; analyzeError = ""; analyzeProgress = 0f
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { ChordAnalyzer(context).analyze(uri) { p -> scope.launch { analyzeProgress = p } } } }
                    .onSuccess { result ->
                        val name = uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "שיר חדש"
                        val song = Song(library.newId(), name, uri = uri.toString(), durationMs = result.durationMs, chords = result.segments)
                        library.save(song); songs = library.load(); currentSong = song; pendingLoop = null; analyzing = false; screen = Screen.PLAYER
                    }
                    .onFailure { e ->
                        analyzing = false
                        analyzeError = "לא הצלחתי לנתח את הקובץ: ${e.message ?: "פורמט לא נתמך"}"
                    }
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = CardBg, primary = Green)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            if (profile == null) {
                Onboarding { p -> prefs.saveProfile(p); profile = p }
            } else {
                val cfg = remoteConfig
                val currentVersion = com.chordflow.guitar.BuildConfig.VERSION_CODE
                val mandatoryUpdate = cfg != null && cfg.apkUrl.startsWith("https://") &&
                    cfg.latestVersionCode > currentVersion && (cfg.forceUpdate || currentVersion < cfg.minSupportedVersionCode)
                if (mandatoryUpdate) {
                    ForceUpdateScreen(cfg!!)
                } else Column(Modifier.fillMaxSize()) {
                    cfg?.let { rc ->
                        val needsUpdate = rc.latestVersionCode > currentVersion
                        if (needsUpdate || rc.announcement != null) {
                            UpdateBanner(rc, needsUpdate)
                        }
                    }
                    Box(Modifier.weight(1f)) {
                        when (screen) {
                            Screen.HOME -> HomeScreen(
                                profile!!, songs, analyzing, analyzeProgress, analyzeError,
                                onImport = { importer.launch(arrayOf("audio/*")) },
                                onSong = { currentSong = it; pendingLoop = null; screen = Screen.PLAYER },
                                onTuner = { screen = Screen.TUNER },
                                onDemo = {
                                    currentSong = Song(
                                        id = "demo-c-g-am-f",
                                        title = "ChordFlow Demo",
                                        artist = "Practice loop",
                                        durationMs = 16_000,
                                        chords = listOf(
                                            ChordSegment("C",0,4_000,1f),
                                            ChordSegment("G",4_000,8_000,1f),
                                            ChordSegment("Am",8_000,12_000,1f),
                                            ChordSegment("F",12_000,16_000,1f)
                                        )
                                    )
                                    pendingLoop = null
                                    screen = Screen.PLAYER
                                }
                            )
                            Screen.LIBRARY -> LibraryScreen(songs, onSong = { currentSong = it; pendingLoop = null; screen = Screen.PLAYER }, onDelete = { library.delete(it.id); songs = library.load() })
                            Screen.PLAYER -> currentSong?.let { song ->
                                PlayerScreen(
                                    song = song,
                                    initialLoopRange = pendingLoop,
                                    onLoopConsumed = { pendingLoop = null },
                                    onUpdateSong = { updated -> library.save(updated); songs = library.load(); currentSong = updated },
                                    onPractice = { screen = Screen.PRACTICE }
                                )
                            } ?: EmptyState("בחר שיר מהספרייה")
                            Screen.PRACTICE -> currentSong?.let { song ->
                                PracticeScreen(
                                    profile = profile!!,
                                    song = song,
                                    onBackToPlayer = { screen = Screen.PLAYER },
                                    onLoopTransition = { range -> pendingLoop = range; screen = Screen.PLAYER }
                                )
                            } ?: EmptyState("אין שיר פתוח")
                            Screen.TUNER -> TunerScreen()
                            Screen.SETTINGS -> SettingsScreen(profile!!, role, prefs, onProfile = { prefs.saveProfile(it); profile = it }, onRoleChanged = { role = it; prefs.setRole(it) }, onAdmin = { screen = Screen.ADMIN }, onReset = { library.clear(); prefs.clearAll(); songs = emptyList(); profile = null })
                            Screen.ADMIN -> AdminScreen(role, prefs, onRoleChanged = { role = it; prefs.setRole(it) })
                        }
                    }
                    if (screen != Screen.PLAYER || currentSong != null) BottomBar(screen) { screen = it }
                }
            }
            }
        }
    }
}

@Composable
private fun Onboarding(onDone: (MusicianProfile) -> Unit) {
    var level by remember { mutableStateOf(SkillLevel.BEGINNER) }
    var known by remember { mutableStateOf(setOf("C","G","Am","Em","D")) }
    var styles by remember { mutableStateOf(setOf("Pop")) }
    var goal by remember { mutableStateOf(Goal.SONGS) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Text("ChordFlow", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Black)
        Text("נתאים את האפליקציה לנגינה שלך", color = Muted)
        Spacer(Modifier.height(28.dp)); Text("מה הרמה שלך?", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { SkillLevel.entries.forEach { FilterChip(it == level, { level = it }, { Text(when(it){SkillLevel.BEGINNER->"מתחיל";SkillLevel.INTERMEDIATE->"בינוני";SkillLevel.ADVANCED->"מתקדם"}) }) } }
        Spacer(Modifier.height(18.dp)); Text("איזה סגנון אתה אוהב?", fontWeight = FontWeight.Bold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Pop","Rock","Folk","Indie","ישראלי").forEach { style ->
                FilterChip(style in styles, { styles = if (style in styles) styles-style else styles+style }, { Text(style) })
            }
        }
        Spacer(Modifier.height(18.dp)); Text("אילו אקורדים אתה יודע?", fontWeight = FontWeight.Bold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("C","G","D","A","E","Am","Em","Dm","F","Bm").forEach { c -> FilterChip(c in known, { known = if (c in known) known-c else known+c }, { Text(c) }) } }
        Spacer(Modifier.height(18.dp)); Text("מה הכי חשוב לך?", fontWeight = FontWeight.Bold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Goal.entries.forEach { g -> FilterChip(g==goal, {goal=g}, {Text(when(g){Goal.SONGS->"שירים";Goal.STRUMMING->"פריטות";Goal.FINGERSTYLE->"Fingerstyle";Goal.SOLOS->"סולואים"})}) } }
        Spacer(Modifier.height(24.dp)); Button(onClick = { onDone(MusicianProfile(level=level, styles=styles.ifEmpty{setOf("Pop")}, knownChords=known, goals=setOf(goal))) }, Modifier.fillMaxWidth()) { Text("התחל לנגן") }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun HomeScreen(profile: MusicianProfile, songs: List<Song>, analyzing: Boolean, progress: Float, error: String, onImport: () -> Unit, onSong: (Song)->Unit, onTuner:()->Unit, onDemo:()->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("ערב טוב", color = Muted); Text("מה מנגנים היום?", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF15221B))) {
                Column(Modifier.padding(18.dp)) {
                    Text("הוסף שיר", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                    Text("MP3 / M4A / WAV — הניתוח מתבצע בטלפון", color = Muted)
                    Spacer(Modifier.height(12.dp)); Button(onClick=onImport) { Text("בחר קובץ") }
                    if (analyzing) { Spacer(Modifier.height(12.dp)); LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth()); Text("מנתח אקורדים… ${(progress*100).toInt()}%", color=Muted) }
                    if (error.isNotBlank()) { Spacer(Modifier.height(10.dp)); Text(error, color=Color(0xFFE88787), style=MaterialTheme.typography.bodySmall) }
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { QuickCard("טיונר", "מיקרופון", onTuner); QuickCard("נסה דמו", "C · G · Am · F", onDemo) } }
        item { InfoCard("הרמה שלך", when(profile.level){SkillLevel.BEGINNER->"מתחיל";SkillLevel.INTERMEDIATE->"בינוני";SkillLevel.ADVANCED->"מתקדם"}) }
        if (songs.isNotEmpty()) item { Text("האחרונים שלך", fontWeight = FontWeight.Bold) }
        items(songs.take(5)) { song -> SongRow(song) { onSong(song) } }
    }
}

@Composable private fun QuickCard(title:String, sub:String, onClick:()->Unit) { Card(Modifier.width(160.dp).clickable(onClick=onClick), colors=CardDefaults.cardColors(containerColor=CardBg)) { Column(Modifier.padding(14.dp)){Text(title,fontWeight=FontWeight.Bold);Text(sub,color=Muted)} } }

@Composable
private fun LibraryScreen(songs: List<Song>, onSong:(Song)->Unit, onDelete:(Song)->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("הספרייה שלי", style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Black) }
        if (songs.isEmpty()) item { EmptyState("השירים שתנתח יופיעו כאן") }
        items(songs) { s -> Row(verticalAlignment=Alignment.CenterVertically) { Box(Modifier.weight(1f)) { SongRow(s){onSong(s)} }; TextButton(onClick={onDelete(s)}){Text("מחק",color=Color(0xFFE88787))} } }
    }
}

@Composable private fun SongRow(song: Song, onClick:()->Unit) { Card(Modifier.fillMaxWidth().clickable(onClick=onClick), colors=CardDefaults.cardColors(containerColor=CardBg)) { Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(song.title,fontWeight=FontWeight.Bold);Text("${song.chords.size} מקטעי אקורדים",color=Muted)};Text("›",style=MaterialTheme.typography.headlineMedium)} } }

@Composable
private fun PlayerScreen(
    song: Song,
    initialLoopRange: Pair<Int,Int>? = null,
    onLoopConsumed: () -> Unit = {},
    onUpdateSong: (Song) -> Unit,
    onPractice:()->Unit
) {
    val context=LocalContext.current
    val player=remember(song.id){AudioPlayer(context)}
    var pos by remember(song.id){mutableIntStateOf(0)}
    var duration by remember(song.id){mutableIntStateOf(song.durationMs.toInt().coerceAtLeast(1))}
    var playing by remember(song.id){mutableStateOf(false)}
    var transpose by remember(song.id){mutableIntStateOf(0)}
    var speed by remember(song.id){mutableFloatStateOf(1f)}
    var selectedChord by remember{mutableStateOf<String?>(null)}
    var popupIndex by remember{mutableIntStateOf(-1)}
    var loopA by remember(song.id){mutableStateOf<Int?>(null)}
    var loopB by remember(song.id){mutableStateOf<Int?>(null)}
    var editIndex by remember{mutableStateOf<Int?>(null)}
    var editValue by remember{mutableStateOf("")}
    val isSilentDemo = song.uri.isBlank()

    fun seekTo(ms:Int){
        val target=ms.coerceIn(0,duration)
        if(isSilentDemo) pos=target else player.seek(target)
    }
    fun togglePlayback(){
        if(isSilentDemo){
            if(pos>=duration) pos=0
            playing=!playing
        }else{
            player.toggle(); playing=player.isPlaying()
        }
    }

    DisposableEffect(song.id) {
        if(song.uri.isNotBlank()) player.load(Uri.parse(song.uri)){duration=it}
        onDispose { player.release() }
    }
    LaunchedEffect(song.id, speed) {
        while(true){
            delay(100)
            if(isSilentDemo){
                if(playing){
                    val next=pos+(100f*speed).toInt().coerceAtLeast(1)
                    val a=loopA; val b=loopB
                    pos=when{
                        a!=null && b!=null && b>a && next>=b -> a
                        next>=duration -> { playing=false; duration }
                        else -> next
                    }
                }
            }else{
                pos=player.position()
                playing=player.isPlaying()
                player.tickLoop()
            }
        }
    }
    LaunchedEffect(song.id, initialLoopRange) {
        initialLoopRange?.let { (a,b) ->
            loopA=a.coerceAtLeast(0)
            loopB=b.coerceAtLeast(a+250)
            player.loopA=loopA
            player.loopB=loopB
            seekTo(a)
            onLoopConsumed()
        }
    }

    val currentIndex = song.chords.indexOfLast { pos >= it.startMs }
    val current = song.chords.getOrNull(currentIndex).orElse(song.chords.firstOrNull())
    val displayCurrent = current?.chord?.let{PracticeEngine.transpose(it,transpose)} ?: "—"

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(song.title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        if(song.artist.isNotBlank()) Text(song.artist,color=Muted)
        Spacer(Modifier.height(16.dp))
        Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF142019)),modifier=Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                Text("עכשיו",color=Muted)
                ChordPopoverAnchor(
                    expanded = selectedChord != null && popupIndex == -2,
                    chord = selectedChord ?: displayCurrent,
                    shape = ChordLibrary.shapeFor(selectedChord ?: displayCurrent),
                    onDismiss = { selectedChord = null; popupIndex = -1 },
                    onEdit = {
                        val idx=currentIndex
                        if(idx>=0){ editIndex=idx; editValue=displayCurrent }
                    }
                ) {
                    Text(
                        displayCurrent,
                        style=MaterialTheme.typography.displayMedium,
                        fontWeight=FontWeight.Black,
                        modifier=Modifier.clickable { selectedChord=displayCurrent; popupIndex=-2 }
                    )
                }
                Text("האקורד הבא: ${nextChord(song,pos,transpose)}",color=Muted)
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("ציר האקורדים",fontWeight=FontWeight.Bold)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(vertical=10.dp),
            horizontalArrangement=Arrangement.spacedBy(7.dp)
        ) {
            song.chords.forEachIndexed { index, seg ->
                val chord=PracticeEngine.transpose(seg.chord,transpose)
                ChordPopoverAnchor(
                    expanded = selectedChord != null && popupIndex == index,
                    chord = selectedChord ?: chord,
                    shape = ChordLibrary.shapeFor(selectedChord ?: chord),
                    onDismiss = { selectedChord = null; popupIndex = -1 },
                    onEdit = { editIndex=index; editValue=chord }
                ) {
                    AssistChip(
                        onClick={ seekTo(seg.startMs.toInt()); selectedChord=chord; popupIndex=index },
                        label={Text(chord)},
                        colors=AssistChipDefaults.assistChipColors(containerColor=if(index==currentIndex) Green.copy(alpha=.22f) else CardBg)
                    )
                }
            }
        }

        Slider(
            value=pos.coerceIn(0,duration).toFloat(),
            onValueChange={seekTo(it.toInt())},
            valueRange=0f..duration.toFloat().coerceAtLeast(1f)
        )
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            Text(formatMs(pos),color=Muted,style=MaterialTheme.typography.labelSmall)
            Text(formatMs(duration),color=Muted,style=MaterialTheme.typography.labelSmall)
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically) {
            TextButton(onClick={seekTo(pos-10000)}){Text("−10")}
            Button(onClick={togglePlayback()}){Text(if(playing)"עצור" else "נגן")}
            TextButton(onClick={seekTo(pos+10000)}){Text("+10")}
        }
        }

        Spacer(Modifier.height(8.dp))
        Card(colors=CardDefaults.cardColors(containerColor=CardBg),modifier=Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Text("מהירות",fontWeight=FontWeight.Bold)
                    Text("${"%.2f".format(speed)}×",color=Green,fontWeight=FontWeight.Bold)
                }
                Slider(
                    value=speed,
                    onValueChange={ speed=it; player.speed(it) },
                    valueRange=.5f..1.25f
                )
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) {
                    listOf(.5f,.75f,1f,1.25f).forEach { v ->
                        TextButton(onClick={speed=v;player.speed(v)}){Text("${v}×")}
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Card(colors=CardDefaults.cardColors(containerColor=CardBg),modifier=Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text("A/B Loop",fontWeight=FontWeight.Bold)
                Text(
                    when {
                        loopA==null -> "בחר נקודת A"
                        loopB==null -> "A ${formatMs(loopA!!)} · עכשיו בחר B"
                        else -> "${formatMs(loopA!!)} → ${formatMs(loopB!!)}"
                    },
                    color=Muted
                )
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick={loopA=pos;loopB=null;player.loopA=pos;player.loopB=null},Modifier.weight(1f)){Text("קבע A")}
                    OutlinedButton(
                        onClick={
                            val a=loopA
                            if(a!=null && pos>a+250){loopB=pos;player.loopA=a;player.loopB=pos}
                        },
                        enabled=loopA!=null,
                        modifier=Modifier.weight(1f)
                    ){Text("קבע B")}
                    TextButton(onClick={loopA=null;loopB=null;player.loopA=null;player.loopB=null}){Text("נקה")}
                }
            }
        }

        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
            TextButton(onClick={transpose--}){Text("♭")}
            Text("Transpose $transpose",color=Muted)
            TextButton(onClick={transpose++}){Text("♯")}
            Button(onClick=onPractice){Text("תרגול")}
        }
        Spacer(Modifier.height(90.dp))
    }

    editIndex?.let { idx ->
        AlertDialog(
            onDismissRequest={editIndex=null},
            title={Text("תקן אקורד")},
            text={
                Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Text("בחר את האקורד שאתה רוצה לראות ולנגן בנקודה הזאת.",color=Muted)
                    OutlinedTextField(editValue,{editValue=it.trim()},label={Text("אקורד")},singleLine=true)
                    FlowRow(horizontalArrangement=Arrangement.spacedBy(6.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                        listOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B","Am","Em","Dm","Bm","E7","A7").forEach { c ->
                            FilterChip(editValue==c,{editValue=c},{Text(c)})
                        }
                    }
                }
            },
            confirmButton={
                TextButton(onClick={
                    if(idx in song.chords.indices && editValue.isNotBlank()){
                        val underlying=PracticeEngine.transpose(editValue.trim(),-transpose)
                        val updated=song.chords.toMutableList()
                        updated[idx]=updated[idx].copy(chord=underlying,confidence=1f)
                        onUpdateSong(song.copy(chords=updated))
                    }
                    editIndex=null
                }){Text("שמור")}
            },
            dismissButton={TextButton(onClick={editIndex=null}){Text("ביטול")}}
        )
    }
}

private fun <T> T?.orElse(other:T?):T? = this ?: other

private fun nextChord(song:Song,pos:Int,transpose:Int):String = song.chords.firstOrNull{it.startMs>pos}?.chord?.let{PracticeEngine.transpose(it,transpose)} ?: "—"
private fun formatMs(ms:Int):String { val total=(ms.coerceAtLeast(0)/1000); return "%d:%02d".format(total/60,total%60) }

@Composable
private fun PracticeScreen(
    profile:MusicianProfile,
    song:Song,
    onBackToPlayer:()->Unit,
    onLoopTransition:(Pair<Int,Int>)->Unit
){
    val plan=remember(song.id,profile){PracticeEngine.build(profile,song.chords)}
    var bpm by remember{mutableIntStateOf(plan.startBpm)}
    val metro=remember{Metronome()}
    var running by remember{mutableStateOf(false)}
    var tapHistory by remember{mutableStateOf<List<Long>>(emptyList())}
    var openEasyChord by remember{mutableStateOf<String?>(null)}
    DisposableEffect(Unit){onDispose{metro.release()}}

    LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{
            Text("Practice Studio",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Black)
            Text(song.title,color=Muted)
        }
        item{
            Card(colors=CardDefaults.cardColors(containerColor=CardBg),modifier=Modifier.fillMaxWidth()){
                Column(Modifier.padding(16.dp)){
                    Text("גרסה קלה · קאפו ${plan.capo}",fontWeight=FontWeight.Bold)
                    Text("לחץ על אקורד כדי לראות אצבוע",color=Muted,style=MaterialTheme.typography.bodySmall)
                    FlowRow(horizontalArrangement=Arrangement.spacedBy(6.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                        plan.easyChords.forEach { chord ->
                            ChordPopoverAnchor(
                                expanded = openEasyChord == chord,
                                chord = chord,
                                shape = ChordLibrary.shapeFor(chord),
                                onDismiss = { openEasyChord = null }
                            ) {
                                AssistChip(onClick={openEasyChord=chord},label={Text(chord)})
                            }
                        }
                    }
                }
            }
        }
        item{InfoCard("פריטה",plan.strumming)}
        item{InfoCard("Fingerstyle",plan.fingerstyle)}
        item{InfoCard("סולו","${plan.soloScale}\n${plan.soloExercise}")}
        item{
            Card(colors=CardDefaults.cardColors(containerColor=CardBg)){
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                        Text("מטרונום",fontWeight=FontWeight.Bold)
                        Text("יעד ${plan.targetBpm} BPM",color=Muted)
                    }
                    Row(verticalAlignment=Alignment.CenterVertically){
                        TextButton(onClick={bpm=(bpm-5).coerceAtLeast(30);metro.bpm=bpm}){Text("−")}
                        Text("$bpm BPM",Modifier.weight(1f),fontWeight=FontWeight.Bold)
                        TextButton(onClick={bpm=(bpm+5).coerceAtMost(240);metro.bpm=bpm}){Text("+")}
                        Button(onClick={metro.bpm=bpm;if(running)metro.stop()else metro.startWithFallback();running=!running}){Text(if(running)"עצור" else "התחל")}
                    }
                    OutlinedButton(
                        onClick={
                            val now=android.os.SystemClock.elapsedRealtime()
                            val last=tapHistory.lastOrNull()
                            tapHistory=if(last==null || now-last>2000) listOf(now) else (tapHistory+now).takeLast(6)
                            if(tapHistory.size>=2){
                                val intervals=tapHistory.zipWithNext{a,b->b-a}
                                val avg=intervals.average()
                                if(avg>0){bpm=(60000.0/avg).toInt().coerceIn(30,240);metro.bpm=bpm}
                            }
                        },
                        modifier=Modifier.fillMaxWidth()
                    ){Text("Tap Tempo")}
                }
            }
        }
        item{Text("מעברים שכדאי לתרגל",fontWeight=FontWeight.Bold)}
        items(plan.transitions){(a,b)->
            val displayA=PracticeEngine.simplify(PracticeEngine.transpose(a,-plan.capo))
            val displayB=PracticeEngine.simplify(PracticeEngine.transpose(b,-plan.capo))
            Card(colors=CardDefaults.cardColors(containerColor=CardBg),modifier=Modifier.fillMaxWidth()){
                Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){
                        Text("$displayA → $displayB",fontWeight=FontWeight.Bold)
                        if(plan.capo>0 && (displayA!=a || displayB!=b)) Text("במקור: $a → $b · קאפו ${plan.capo}",color=Muted,style=MaterialTheme.typography.bodySmall)
                        Text("20 החלפות נקיות · העלה קצב בהדרגה",color=Muted)
                    }
                    transitionLoopRange(song,a,b)?.let{range->
                        TextButton(onClick={onLoopTransition(range)}){Text("תרגל בלופ")}
                    }
                }
            }
        }
        item{Button(onClick=onBackToPlayer,Modifier.fillMaxWidth()){Text("חזרה לנגן")}}
        item{Spacer(Modifier.height(80.dp))}
    }
}

private fun transitionLoopRange(song:Song,a:String,b:String):Pair<Int,Int>? {
    for(i in 0 until song.chords.lastIndex){
        val first=song.chords[i]
        val second=song.chords[i+1]
        if(first.chord==a && second.chord==b){
            val pad=250
            return (first.startMs.toInt()-pad).coerceAtLeast(0) to (second.endMs.toInt()+pad).coerceAtMost(song.durationMs.toInt())
        }
    }
    return null
}

@Composable private fun InfoCard(title:String,body:String){Card(colors=CardDefaults.cardColors(containerColor=CardBg),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(title,fontWeight=FontWeight.Bold);Text(body,color=Muted)}}}

@Composable
private fun TunerScreen(){
    val context=LocalContext.current
    val tuner=remember{TunerEngine()}
    var pitch by remember{mutableStateOf<TunerEngine.Pitch?>(null)}
    var running by remember{mutableStateOf(false)}
    var a4 by remember{mutableFloatStateOf(440f)}
    val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){granted->
        if(granted){tuner.start(a4){pitch=it};running=true}
    }
    DisposableEffect(Unit){onDispose{tuner.stop()}}
    val cents=pitch?.cents ?: 0f
    val tuneText=when{
        pitch==null -> "פרוט מיתר"
        cents < -5 -> "נמוך — מתח קצת"
        cents > 5 -> "גבוה — שחרר קצת"
        else -> "מכוון"
    }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment=Alignment.CenterHorizontally,
        verticalArrangement=Arrangement.Center
    ){
        Text("טיונר",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Black)
        Text("E2 · A2 · D3 · G3 · B3 · E4",color=Muted,style=MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(28.dp))
        Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF142019)),modifier=Modifier.fillMaxWidth()){
            Column(Modifier.padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally){
                Text(pitch?.note?:"—",style=MaterialTheme.typography.displayLarge,fontWeight=FontWeight.Black,color=if(kotlin.math.abs(cents)<=5&&pitch!=null) Green else Color.White)
                Text(pitch?.let{"%.1f Hz · %+.1f cents".format(it.hz,it.cents)}?:"A4 = ${a4.toInt()} Hz",color=Muted)
                Spacer(Modifier.height(18.dp))
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr){
                    LinearProgressIndicator(
                        progress={((cents.coerceIn(-50f,50f)+50f)/100f)},
                        modifier=Modifier.fillMaxWidth().height(8.dp)
                    )
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("−50",color=Muted);Text("0",color=Muted);Text("+50",color=Muted)}
                }
                Spacer(Modifier.height(10.dp))
                Text(tuneText,fontWeight=FontWeight.Bold,color=if(kotlin.math.abs(cents)<=5&&pitch!=null) Green else Muted)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically){
            TextButton(onClick={if(!running)a4=(a4-1f).coerceAtLeast(430f)},enabled=!running){Text("−")}
            Text("A4 = ${a4.toInt()} Hz",fontWeight=FontWeight.Bold)
            TextButton(onClick={if(!running)a4=(a4+1f).coerceAtMost(450f)},enabled=!running){Text("+")}
        }
        Text("אפשר לשנות את הייחוס לפני שמתחילים את הטיונר",color=Muted,style=MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Button(onClick={
            if(running){tuner.stop();running=false;pitch=null}
            else permission.launch(Manifest.permission.RECORD_AUDIO)
        },Modifier.fillMaxWidth()){
            Text(if(running)"עצור טיונר" else "התחל טיונר")
        }
    }
}

@Composable
private fun SettingsScreen(
    profile:MusicianProfile,
    role:UserRole,
    prefs:AppPreferences,
    onProfile:(MusicianProfile)->Unit,
    onRoleChanged:(UserRole)->Unit,
    onAdmin:()->Unit,
    onReset:()->Unit
){
    val context=LocalContext.current
    var inviteCode by remember{mutableStateOf("")}
    var accessStatus by remember{mutableStateOf("")}
    var controlUrl by remember{mutableStateOf(prefs.getControlUrl())}
    var showOwnerSetup by remember{mutableStateOf(false)}
    var ownerToken by remember{mutableStateOf("")}
    val scope=rememberCoroutineScope()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement=Arrangement.spacedBy(12.dp)
    ){
        Text("הגדרות",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Black)
        InfoCard("חשבון","תפקיד: ${role.name}")
        if(role==UserRole.OWNER||role==UserRole.ADMIN){
            Button(onClick=onAdmin,Modifier.fillMaxWidth()){Text("פתח מרכז ניהול")}
        } else {
            Card(colors=CardDefaults.cardColors(containerColor=CardBg),modifier=Modifier.fillMaxWidth()){
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Text("גישה מחבר / Tester",fontWeight=FontWeight.Bold)
                    Text("אם קיבלת קוד הזמנה ממנהל ChordFlow, הזן אותו כאן.",color=Muted)
                    OutlinedTextField(
                        value=controlUrl,
                        onValueChange={controlUrl=it},
                        label={Text("שרת ChordFlow HTTPS")},
                        modifier=Modifier.fillMaxWidth(),
                        singleLine=true
                    )
                    OutlinedTextField(
                        value=inviteCode,
                        onValueChange={inviteCode=it.uppercase()},
                        label={Text("קוד הזמנה")},
                        modifier=Modifier.fillMaxWidth(),
                        singleLine=true
                    )
                    Button(
                        onClick={
                            prefs.setControlUrl(controlUrl)
                            scope.launch{
                                accessStatus="מאמת קוד…"
                                runCatching{withContext(Dispatchers.IO){ControlClient(controlUrl).redeemInvite(inviteCode,android.os.Build.MODEL)}}
                                    .onSuccess{result->
                                        prefs.setUserToken(result.token)
                                        prefs.setRole(result.role)
                                        onRoleChanged(result.role)
                                        accessStatus="הגישה הופעלה: ${result.role.name}"
                                    }
                                    .onFailure{accessStatus=it.message?:"קוד לא תקין"}
                            }
                        },
                        enabled=inviteCode.isNotBlank()&&controlUrl.startsWith("https://"),
                        modifier=Modifier.fillMaxWidth()
                    ){Text("הפעל הזמנה")}
                    if(accessStatus.isNotBlank())Text(accessStatus,color=Muted)
                }
            }
        }
        if(role!=UserRole.OWNER){
            TextButton(onClick={showOwnerSetup=!showOwnerSetup},Modifier.fillMaxWidth()){
                Text(if(showOwnerSetup) "סגור הפעלת Owner" else "אני הבעלים של ChordFlow")
            }
            if(showOwnerSetup){
                Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF17141F)),modifier=Modifier.fillMaxWidth()){
                    Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                        Text("הפעלת Owner",fontWeight=FontWeight.Bold)
                        Text("האימות מתבצע מול שרת הניהול. אין סיסמת מנהל קבועה בתוך ה-APK.",color=Muted)
                        OutlinedTextField(
                            value=controlUrl,
                            onValueChange={controlUrl=it},
                            label={Text("שרת ChordFlow HTTPS")},
                            modifier=Modifier.fillMaxWidth(),
                            singleLine=true
                        )
                        OutlinedTextField(
                            value=ownerToken,
                            onValueChange={ownerToken=it},
                            label={Text("Owner token")},
                            modifier=Modifier.fillMaxWidth(),
                            singleLine=true,
                            visualTransformation=PasswordVisualTransformation()
                        )
                        Button(
                            onClick={
                                prefs.setControlUrl(controlUrl)
                                scope.launch{
                                    accessStatus="מאמת בעלים…"
                                    runCatching{withContext(Dispatchers.IO){ControlClient(controlUrl,ownerToken).verifyOwner()}}
                                        .onSuccess{ok->
                                            if(ok){
                                                prefs.setOwnerToken(ownerToken)
                                                prefs.setRole(UserRole.OWNER)
                                                onRoleChanged(UserRole.OWNER)
                                                accessStatus="Owner הופעל במכשיר הזה"
                                                showOwnerSetup=false
                                            }else accessStatus="האימות נכשל"
                                        }
                                        .onFailure{accessStatus=it.message?:"האימות נכשל"}
                                }
                            },
                            enabled=controlUrl.startsWith("https://")&&ownerToken.isNotBlank(),
                            modifier=Modifier.fillMaxWidth()
                        ){Text("אמת והפעל Owner")}
                    }
                }
            }
        }
        InfoCard("Spotify","כבוי כרגע — נחבר אחר כך")
        OutlinedButton(onClick=onReset,Modifier.fillMaxWidth()){Text("איפוס כל הנתונים")}
    }
}

@Composable
private fun AdminScreen(role:UserRole,prefs:AppPreferences,onRoleChanged:(UserRole)->Unit){
    val context=LocalContext.current
    var url by remember{mutableStateOf(prefs.getControlUrl())}
    var token by remember{mutableStateOf(if(role==UserRole.OWNER) prefs.getOwnerToken() else prefs.getUserToken())}
    var status by remember{mutableStateOf("")}
    var latest by remember{mutableStateOf<RemoteConfig?>(null)}
    var announcement by remember{mutableStateOf("")}
    var forceUpdate by remember{mutableStateOf(false)}
    var latestVersionName by remember{mutableStateOf("")}
    var latestVersionCode by remember{mutableStateOf("")}
    var minSupportedVersionCode by remember{mutableStateOf("")}
    var apkUrl by remember{mutableStateOf("")}
    var apkSha256 by remember{mutableStateOf("")}
    var shareUrl by remember{mutableStateOf("")}
    var updateMessage by remember{mutableStateOf("")}
    var featureSpotify by remember{mutableStateOf(false)}
    var featureAnalyzer by remember{mutableStateOf(true)}
    var featureCommunity by remember{mutableStateOf(false)}
    var inviteLabel by remember{mutableStateOf("")}
    var inviteRole by remember{mutableStateOf(UserRole.TESTER)}
    var inviteCode by remember{mutableStateOf("")}
    var managedUsers by remember{mutableStateOf<List<ControlClient.ManagedUser>>(emptyList())}
    val scope=rememberCoroutineScope()

    fun adoptConfig(cfg:RemoteConfig){
        latest=cfg
        announcement=cfg.announcement?.message.orEmpty()
        forceUpdate=cfg.forceUpdate
        latestVersionName=cfg.latestVersionName
        latestVersionCode=cfg.latestVersionCode.toString()
        minSupportedVersionCode=cfg.minSupportedVersionCode.toString()
        apkUrl=cfg.apkUrl
        apkSha256=cfg.apkSha256
        shareUrl=cfg.shareUrl
        updateMessage=cfg.updateMessage
        featureSpotify=cfg.features.spotify
        featureAnalyzer=cfg.features.experimentalAnalyzer
        featureCommunity=cfg.features.community
    }

    fun refreshUsers(){
        scope.launch{
            runCatching{withContext(Dispatchers.IO){ControlClient(url,token).listUsers()}}
                .onSuccess{managedUsers=it}
                .onFailure{status=it.message?:"שגיאה בטעינת משתמשים"}
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{Text("ChordFlow Control",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Black);Text("Owner / Admin",color=Green)}
        item{OutlinedTextField(url,{url=it},label={Text("Control Server HTTPS")},modifier=Modifier.fillMaxWidth(),singleLine=true)}
        if(role==UserRole.OWNER){
            item{OutlinedTextField(token,{token=it},label={Text("Owner token")},modifier=Modifier.fillMaxWidth(),singleLine=true,visualTransformation=PasswordVisualTransformation())}
        } else {
            item{InfoCard("Admin","הגישה מאומתת באמצעות קוד ההזמנה שלך. אין צורך ב-Owner token.")}
        }
        item{Button(onClick={
            prefs.setControlUrl(url)
            if(role==UserRole.OWNER) prefs.setOwnerToken(token)
            scope.launch{
                status=if(role==UserRole.OWNER) "מאמת בעלים…" else "מאמת Admin…"
                runCatching{withContext(Dispatchers.IO){
                    val c=ControlClient(url,token)
                    if(role==UserRole.OWNER){
                        if(!c.verifyOwner()) error("האימות נכשל")
                    } else {
                        if(c.fetchMe(token)!=UserRole.ADMIN) error("הרשאת Admin לא תקפה")
                    }
                    c.fetchConfig()
                }}
                    .onSuccess{adoptConfig(it);status=if(role==UserRole.OWNER) "מחובר כבעלים" else "מחובר כ-Admin";if(role==UserRole.OWNER)onRoleChanged(UserRole.OWNER);refreshUsers()}
                    .onFailure{status=it.message?:"שגיאה"}
            }
        },Modifier.fillMaxWidth()){Text(if(role==UserRole.OWNER)"חבר ואמת Owner" else "טען מרכז ניהול")}}
        item{Text(status,color=Muted)}

        latest?.let{cfg->
            item{InfoCard("גרסה אצל המשתמשים","Latest ${cfg.latestVersionName} (${cfg.latestVersionCode})\n${cfg.updateMessage}")}
            item{
                Card(colors=CardDefaults.cardColors(containerColor=CardBg),modifier=Modifier.fillMaxWidth()){
                    Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                        Text("Feature flags",fontWeight=FontWeight.Bold)
                        Row(verticalAlignment=Alignment.CenterVertically){Switch(featureAnalyzer,{featureAnalyzer=it});Spacer(Modifier.width(8.dp));Text("Analyzer ניסיוני")}
                        Row(verticalAlignment=Alignment.CenterVertically){Switch(featureSpotify,{featureSpotify=it});Spacer(Modifier.width(8.dp));Text("Spotify")}
                        Row(verticalAlignment=Alignment.CenterVertically){Switch(featureCommunity,{featureCommunity=it});Spacer(Modifier.width(8.dp));Text("Community")}
                    }
                }
            }
            item{OutlinedTextField(announcement,{announcement=it},label={Text("הודעה לכל המשתמשים")},modifier=Modifier.fillMaxWidth())}
            if(role==UserRole.OWNER){
                item{
                    Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF17141F)),modifier=Modifier.fillMaxWidth()){
                        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                            Text("פרסום גרסה",fontWeight=FontWeight.Bold)
                            Text("רק Owner יכול לשנות APK או לכפות עדכון.",color=Muted)
                            OutlinedTextField(latestVersionName,{latestVersionName=it},label={Text("Version name")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                                OutlinedTextField(latestVersionCode,{latestVersionCode=it.filter(Char::isDigit)},label={Text("Version code")},modifier=Modifier.weight(1f),singleLine=true)
                                OutlinedTextField(minSupportedVersionCode,{minSupportedVersionCode=it.filter(Char::isDigit)},label={Text("Min supported")},modifier=Modifier.weight(1f),singleLine=true)
                            }
                            OutlinedTextField(apkUrl,{apkUrl=it},label={Text("APK HTTPS URL")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                            OutlinedTextField(apkSha256,{apkSha256=it.lowercase().filter{c->c in '0'..'9'||c in 'a'..'f'}},label={Text("APK SHA-256")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                            OutlinedTextField(shareUrl,{shareUrl=it},label={Text("קישור שיתוף")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                            OutlinedTextField(updateMessage,{updateMessage=it},label={Text("מה חדש בגרסה")},modifier=Modifier.fillMaxWidth())
                            Row(verticalAlignment=Alignment.CenterVertically){Switch(forceUpdate,{forceUpdate=it});Spacer(Modifier.width(8.dp));Text("עדכון חובה")}
                        }
                    }
                }
            }
            item{Button(onClick={scope.launch{
                val patch=JSONObject()
                    .put("features",JSONObject().put("spotify",featureSpotify).put("experimentalAnalyzer",featureAnalyzer).put("community",featureCommunity))
                    .put("announcement",if(announcement.isBlank()) JSONObject.NULL else JSONObject().put("id",System.currentTimeMillis().toString()).put("title","הודעה מ-ChordFlow").put("message",announcement))
                if(role==UserRole.OWNER){
                    patch.put("forceUpdate",forceUpdate)
                        .put("latestVersionName",latestVersionName.trim())
                        .put("latestVersionCode",latestVersionCode.toIntOrNull()?:cfg.latestVersionCode)
                        .put("minSupportedVersionCode",minSupportedVersionCode.toIntOrNull()?:cfg.minSupportedVersionCode)
                        .put("apkUrl",apkUrl.trim())
                        .put("apkSha256",apkSha256.trim())
                        .put("shareUrl",shareUrl.trim())
                        .put("updateMessage",updateMessage.trim())
                }
                status=runCatching{withContext(Dispatchers.IO){ControlClient(url,token).updateConfig(patch)}}.fold({if(it)"פורסם" else "השרת דחה את השינוי"},{it.message?:"שגיאה"})
                if(status=="פורסם") runCatching{withContext(Dispatchers.IO){ControlClient(url,token).fetchConfig()}}.onSuccess{adoptConfig(it)}
            }},Modifier.fillMaxWidth()){Text("פרסם הגדרות")}}

            item{
                Card(colors=CardDefaults.cardColors(containerColor=CardBg),modifier=Modifier.fillMaxWidth()){
                    Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                        Text("הזמן חבר",fontWeight=FontWeight.Bold)
                        OutlinedTextField(inviteLabel,{inviteLabel=it},label={Text("שם / הערה")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                        FlowRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                            (if(role==UserRole.OWNER) listOf(UserRole.ADMIN,UserRole.TESTER,UserRole.USER) else listOf(UserRole.TESTER,UserRole.USER)).forEach{r->
                                FilterChip(inviteRole==r,{inviteRole=r},{Text(r.name)})
                            }
                        }
                        Button(onClick={scope.launch{
                            status="יוצר הזמנה…"
                            runCatching{withContext(Dispatchers.IO){ControlClient(url,token).createInvite(inviteRole,inviteLabel)}}
                                .onSuccess{result->inviteCode=result.code;status="קוד נוצר"}
                                .onFailure{status=it.message?:"שגיאה"}
                        }},Modifier.fillMaxWidth()){Text("צור קוד הזמנה")}
                        if(inviteCode.isNotBlank()){
                            Text(inviteCode,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Black,color=Green)
                            OutlinedButton(onClick={
                                val cm=context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("ChordFlow invite",inviteCode));status="קוד ההזמנה הועתק"
                            },Modifier.fillMaxWidth()){Text("העתק קוד")}
                        }
                    }
                }
            }

            item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("משתמשים",fontWeight=FontWeight.Bold);TextButton(onClick={refreshUsers()}){Text("רענן")}}}
            items(managedUsers,key={it.id}){u->
                Card(colors=CardDefaults.cardColors(containerColor=CardBg),modifier=Modifier.fillMaxWidth()){
                    Column(Modifier.padding(14.dp)){
                        Text(u.label.ifBlank{"User"},fontWeight=FontWeight.Bold)
                        Text(u.role.name,color=Muted)
                        FlowRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                            (if(role==UserRole.OWNER) listOf(UserRole.ADMIN,UserRole.TESTER,UserRole.USER) else listOf(UserRole.TESTER,UserRole.USER)).forEach{r->
                                FilterChip(u.role==r,{
                                    scope.launch{
                                        val ok=runCatching{withContext(Dispatchers.IO){ControlClient(url,token).setUserRole(u.id,r)}}.getOrDefault(false)
                                        status=if(ok)"התפקיד עודכן" else "עדכון התפקיד נכשל"
                                        if(ok)refreshUsers()
                                    }
                                },{Text(r.name)})
                            }
                        }
                    }
                }
            }

            if(cfg.shareUrl.isNotBlank()) item{OutlinedButton(onClick={
                val cm=context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("ChordFlow",cfg.shareUrl));status="קישור ההתקנה הועתק"
            },Modifier.fillMaxWidth()){Text("העתק קישור לשליחה לחברים")}}
        }
        if(role==UserRole.USER) item{Text("תפקיד Owner מתקבל רק אחרי אימות מול השרת. אין סיסמת מנהל קשיחה בתוך ה-APK.",color=Muted)}
    }
}

@Composable
private fun ForceUpdateScreen(cfg:RemoteConfig){
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    var progress by remember{mutableFloatStateOf(0f)}
    var downloading by remember{mutableStateOf(false)}
    var error by remember{mutableStateOf("")}
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment=Alignment.CenterHorizontally,
        verticalArrangement=Arrangement.Center
    ){
        Text("נדרש עדכון",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Black)
        Spacer(Modifier.height(8.dp))
        Text("כדי להמשיך להשתמש ב-ChordFlow צריך לעדכן לגרסה ${cfg.latestVersionName}.",color=Muted)
        if(cfg.updateMessage.isNotBlank()){Spacer(Modifier.height(8.dp));Text(cfg.updateMessage,color=Muted)}
        if(downloading){Spacer(Modifier.height(14.dp));LinearProgressIndicator(progress={progress},modifier=Modifier.fillMaxWidth());Text("מוריד ומאמת… ${(progress*100).toInt()}%",color=Muted)}
        if(error.isNotBlank()){Spacer(Modifier.height(10.dp));Text(error,color=Color(0xFFE88787))}
        Spacer(Modifier.height(22.dp))
        Button(onClick={
            val installer=UpdateInstaller(context)
            if(!installer.canInstallPackages()) installer.openInstallPermission()
            else scope.launch{
                downloading=true;error=""
                runCatching{installer.downloadVerifiedApk(cfg.apkUrl,cfg.latestVersionName,cfg.apkSha256){p->scope.launch{progress=p}}}
                    .onSuccess{installer.launchInstaller(it.uri)}
                    .onFailure{error=it.message?:"העדכון נכשל"}
                downloading=false
            }
        },enabled=!downloading,modifier=Modifier.fillMaxWidth()){Text(if(downloading)"מוריד…" else "הורד עדכון")}
    }
}

@Composable
private fun UpdateBanner(cfg:RemoteConfig,needsUpdate:Boolean){
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    var busy by remember{mutableStateOf(false)}
    Card(Modifier.fillMaxWidth().padding(horizontal=10.dp,vertical=6.dp),colors=CardDefaults.cardColors(containerColor=if(needsUpdate) Color(0xFF332615) else Color(0xFF142019))){
        Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){
                Text(if(needsUpdate) "יש עדכון ל-ChordFlow ${cfg.latestVersionName}" else cfg.announcement?.title.orEmpty(),fontWeight=FontWeight.Bold)
                Text(if(needsUpdate) cfg.updateMessage else cfg.announcement?.message.orEmpty(),color=Muted,style=MaterialTheme.typography.bodySmall)
            }
            if(needsUpdate && cfg.apkUrl.startsWith("https://")) Button(onClick={
                val installer=UpdateInstaller(context)
                if(!installer.canInstallPackages()) installer.openInstallPermission()
                else scope.launch{
                    busy=true
                    runCatching{installer.downloadVerifiedApk(cfg.apkUrl,cfg.latestVersionName,cfg.apkSha256)}
                        .onSuccess{installer.launchInstaller(it.uri)}
                    busy=false
                }
            },enabled=!busy){Text(if(busy)"…" else "עדכן") }
        }
    }
}

@Composable
private fun BottomBar(current:Screen,onSelect:(Screen)->Unit){NavigationBar(containerColor=Color(0xFF0E141B)){listOf(Screen.HOME to "בית",Screen.LIBRARY to "ספרייה",Screen.TUNER to "טיונר",Screen.SETTINGS to "הגדרות").forEach{(s,t)->NavigationBarItem(selected=current==s,onClick={onSelect(s)},icon={Text(when(s){Screen.HOME->"⌂";Screen.LIBRARY->"♫";Screen.TUNER->"⌁";else->"⚙"})},label={Text(t)})}}}

@Composable private fun EmptyState(text:String){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text(text,color=Muted)}}
