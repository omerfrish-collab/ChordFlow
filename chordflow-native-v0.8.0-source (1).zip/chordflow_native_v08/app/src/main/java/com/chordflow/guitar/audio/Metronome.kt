package com.chordflow.guitar.audio

import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Handler
import android.os.Looper

class Metronome {
    private val handler = Handler(Looper.getMainLooper())
    private var soundPool: SoundPool? = null
    private var soundId = 0
    private var running = false
    private var tone: android.media.ToneGenerator? = null
    var bpm: Int = 70
        set(value) { field = value.coerceIn(30, 240) }

    fun prepare(rawClickResId: Int, context: android.content.Context) {
        soundPool = SoundPool.Builder().setMaxStreams(2)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).build())
            .build()
        soundId = soundPool!!.load(context, rawClickResId, 1)
    }

    fun startWithFallback() {
        if (running) return
        running = true
        handler.post(object : Runnable {
            override fun run() {
                if (!running) return
                if (tone == null) tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 65)
                tone?.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 45)
                handler.postDelayed(this, (60_000L / bpm))
            }
        })
    }

    fun stop() { running = false; handler.removeCallbacksAndMessages(null) }
    fun release() { stop(); soundPool?.release(); soundPool = null; tone?.release(); tone = null }
}
