package com.chordflow.guitar.audio

import kotlin.math.ln
import kotlin.math.round

object PitchMath {
    data class Result(val hz: Float, val note: String, val cents: Float, val confidence: Float)
    private val notes = arrayOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B")

    /** YIN-style fundamental estimation, tuned for guitar-range monophonic input. */
    fun detect(samples: ShortArray, n: Int, sampleRate: Int, a4: Float = 440f): Result? {
        if (n < 1200 || sampleRate <= 0) return null
        val count = n.coerceAtMost(samples.size)
        var mean = 0.0
        for (i in 0 until count) mean += samples[i]
        mean /= count
        var energy = 0.0
        for (i in 0 until count) {
            val x = samples[i] - mean
            energy += x * x
        }
        if (energy / count < 1_200_000.0) return null

        val minLag = (sampleRate / 520).coerceAtLeast(2)
        val maxLag = (sampleRate / 65).coerceAtMost(count / 2)
        if (maxLag <= minLag) return null
        val diff = DoubleArray(maxLag + 1)
        for (tau in 1..maxLag) {
            var sum = 0.0
            val limit = count - tau
            var i = 0
            while (i < limit) {
                val d = (samples[i] - mean) - (samples[i + tau] - mean)
                sum += d * d
                i++
            }
            diff[tau] = sum
        }

        val cmnd = DoubleArray(maxLag + 1) { 1.0 }
        var running = 0.0
        for (tau in 1..maxLag) {
            running += diff[tau]
            cmnd[tau] = if (running <= 1e-12) 1.0 else diff[tau] * tau / running
        }

        var chosen = -1
        val threshold = 0.16
        var tau = minLag
        while (tau < maxLag) {
            if (cmnd[tau] < threshold) {
                while (tau + 1 <= maxLag && cmnd[tau + 1] < cmnd[tau]) tau++
                chosen = tau
                break
            }
            tau++
        }
        if (chosen < 0) {
            chosen = (minLag..maxLag).minByOrNull { cmnd[it] } ?: return null
            if (cmnd[chosen] > 0.32) return null
        }

        var refined = chosen.toDouble()
        if (chosen > 1 && chosen < maxLag) {
            val a = cmnd[chosen - 1]
            val b = cmnd[chosen]
            val c = cmnd[chosen + 1]
            val denom = a - 2 * b + c
            if (kotlin.math.abs(denom) > 1e-12) refined += 0.5 * (a - c) / denom
        }
        val hz = (sampleRate / refined).toFloat()
        if (hz !in 65f..520f) return null
        val midi = 69f + (12f * (ln((hz / a4).toDouble()) / ln(2.0))).toFloat()
        val rounded = round(midi)
        val noteIndex = ((rounded.toInt() % 12) + 12) % 12
        val octave = rounded.toInt() / 12 - 1
        val cents = (midi - rounded) * 100f
        val confidence = (1.0 - cmnd[chosen]).coerceIn(0.0, 1.0).toFloat()
        return Result(hz, notes[noteIndex] + octave, cents, confidence)
    }
}
