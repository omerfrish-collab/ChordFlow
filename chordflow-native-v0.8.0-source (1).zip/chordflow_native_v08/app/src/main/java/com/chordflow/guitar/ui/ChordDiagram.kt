package com.chordflow.guitar.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import com.chordflow.guitar.model.ChordShape

private class BelowAnchorPositionProvider(private val gapPx: Int) : PopupPositionProvider {
    override fun calculatePosition(
        anchorBounds: IntRect,
        windowSize: IntSize,
        layoutDirection: LayoutDirection,
        popupContentSize: IntSize
    ): IntOffset {
        val margin = 12
        val centeredX = anchorBounds.left + (anchorBounds.width - popupContentSize.width) / 2
        val maxX = (windowSize.width - popupContentSize.width - margin).coerceAtLeast(margin)
        val x = centeredX.coerceIn(margin, maxX)

        // User preference: keep the fingering card below/next to the chord, never as a full-screen sheet.
        val requestedY = anchorBounds.bottom + gapPx
        val maxY = (windowSize.height - popupContentSize.height - margin).coerceAtLeast(margin)
        val y = requestedY.coerceAtMost(maxY)
        return IntOffset(x, y)
    }
}

@Composable
fun ChordPopoverAnchor(
    expanded: Boolean,
    chord: String,
    shape: ChordShape?,
    onDismiss: () -> Unit,
    onEdit: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(modifier) {
        content()
        if (expanded && shape != null) {
            Popup(
                popupPositionProvider = BelowAnchorPositionProvider(gapPx = 10),
                onDismissRequest = onDismiss,
                properties = PopupProperties(
                    focusable = true,
                    dismissOnBackPress = true,
                    dismissOnClickOutside = true,
                    clippingEnabled = true
                )
            ) {
                ChordFingeringPopover(chord, shape, onDismiss, onEdit)
            }
        }
    }
}

@Composable
fun ChordFingeringPopover(chord: String, shape: ChordShape?, onDismiss: () -> Unit, onEdit: (() -> Unit)? = null) {
    if (shape == null) return
    Card(
        modifier = Modifier.width(196.dp),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF151C24))
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(chord, color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                    Text("אצבוע לגיטרה", color = Color(0xFF93A4B4), style = MaterialTheme.typography.labelSmall)
                }
                TextButton(onClick = onDismiss, contentPadding = PaddingValues(4.dp)) {
                    Text("×", color = Color(0xFF9BA8B5), style = MaterialTheme.typography.titleLarge)
                }
            }
            ChordDiagram(shape, Modifier.fillMaxWidth().height(132.dp))
            Text("1–4 אצבעות · X לא לנגן · O פתוח", color = Color(0xFF93A4B4), style = MaterialTheme.typography.labelSmall)
            if (onEdit != null) {
                TextButton(onClick = { onDismiss(); onEdit() }) { Text("תקן אקורד") }
            }
        }
    }
}

@Composable
fun ChordDiagram(shape: ChordShape, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val left = size.width * .18f
        val right = size.width * .82f
        val top = size.height * .16f
        val bottom = size.height * .88f
        val stringGap = (right-left)/5f
        val fretGap = (bottom-top)/5f
        val grid = Color(0xFF8A9AA9)
        for (s in 0..5) {
            val x = left + s*stringGap
            drawLine(grid, Offset(x, top), Offset(x, bottom), 2f)
        }
        for (f in 0..5) {
            val y = top + f*fretGap
            drawLine(grid, Offset(left,y), Offset(right,y), if (f==0 && shape.baseFret==1) 6f else 2f)
        }
        shape.barreFret?.let { bf ->
            val rel = (bf - shape.baseFret).coerceAtLeast(0)
            val y = top + (rel + .5f)*fretGap
            val from = shape.barreFromString ?: 6
            val to = shape.barreToString ?: 1
            val x1 = left + (6-from)*stringGap
            val x2 = left + (6-to)*stringGap
            drawLine(Color(0xFF58D68D), Offset(x1,y), Offset(x2,y), 12f, StrokeCap.Round)
            val fingerPaint = android.graphics.Paint().apply {
                color = android.graphics.Color.rgb(11, 15, 20)
                textSize = 18f
                textAlign = android.graphics.Paint.Align.CENTER
                isFakeBoldText = true
            }
            drawContext.canvas.nativeCanvas.drawText(
                "1",
                (x1+x2)/2f,
                y + (fingerPaint.textSize * .34f),
                fingerPaint
            )
        }
        shape.frets.forEachIndexed { i, fret ->
            val x = left + i*stringGap
            when {
                fret == null -> {
                    drawLine(Color(0xFFE36A6A), Offset(x-7, top-22), Offset(x+7, top-8), 3f)
                    drawLine(Color(0xFFE36A6A), Offset(x+7, top-22), Offset(x-7, top-8), 3f)
                }
                fret == 0 -> drawCircle(Color(0xFFB8C7D3), 6f, Offset(x, top-15), style = Stroke(2f))
                else -> {
                    val isCoveredByBarre = shape.barreFret != null && fret == shape.barreFret &&
                        shape.fingers.getOrNull(i) == 1 &&
                        i in ((6-(shape.barreFromString ?: 6))..(6-(shape.barreToString ?: 1)))
                    if (isCoveredByBarre) return@forEachIndexed
                    val rel = (fret - shape.baseFret).coerceAtLeast(0)
                    val y = top + (rel + .5f)*fretGap
                    drawCircle(Color(0xFF58D68D), 12f, Offset(x,y))
                    shape.fingers.getOrNull(i)?.let { finger ->
                        val paint = android.graphics.Paint().apply {
                            color = android.graphics.Color.rgb(11, 15, 20)
                            textSize = 18f
                            textAlign = android.graphics.Paint.Align.CENTER
                            isFakeBoldText = true
                        }
                        drawContext.canvas.nativeCanvas.drawText(
                            finger.toString(),
                            x,
                            y + (paint.textSize * .34f),
                            paint
                        )
                    }
                }
            }
        }
        if (shape.baseFret > 1) {
            drawContext.canvas.nativeCanvas.drawText(
                "${shape.baseFret}fr",
                3f,
                top + fretGap*.6f,
                android.graphics.Paint().apply { color = android.graphics.Color.LTGRAY; textSize = 24f }
            )
        }
    }
}
