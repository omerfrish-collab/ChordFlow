# ChordFlow Native 0.8.0 — verification report

## Passed locally

- Core Kotlin compilation for platform-independent music logic.
- Chord classifier regression: 9/9 synthetic major/minor/dominant-7 targets.
- Tuner pitch engine: 6/6 standard guitar strings at correct note/octave.
- Tuner silence rejection and +12-cent A4 detune test.
- Practice transpose, capo/easy-chord, chord-shape and transition checks.
- Control server JavaScript syntax check.
- Automated control-server integration test passes from a clean temporary data directory.
- Owner verification accepts the correct token and rejects a bad token.
- Owner can create Admin invitations; invitation redemption returns a scoped user token.
- Admin privilege escalation is blocked: Admin cannot create/promote another Admin.
- Admin cannot replace the APK URL or force an update; Owner can.
- Insecure HTTP APK URLs and malformed APK SHA-256 values are rejected.
- Owner can publish release metadata and protected update settings.
- Main Compose/chord-popover sources have no parser-level syntax diagnostics in the local Kotlin smoke parse (full Android symbol resolution still needs the Android SDK).

## Important implementation fixes

- Chord fingering is a small anchored popup, not a modal/full-screen sheet.
- Barre diagrams render a clean barre with finger 1 instead of redundant dots across the same fret.
- Timeline and seek controls stay left-to-right while the app UI is RTL Hebrew.
- Built-in silent C–G–Am–F demo can exercise the player, timeline, loop, transpose and Practice Studio without copyrighted audio.
- Dominant-7 scoring fixed so A7/E7 do not collapse to plain major chords in regression tests.
- Local audio analyzer uses primitive float storage instead of boxed Float objects to reduce memory use on real songs.
- Decoder resources are released on failures.
- Persistable URI permission failure no longer aborts an otherwise valid local import.
- Analysis progress is marshalled back to the Compose/UI coroutine instead of mutating UI state directly from the decoder thread.
- Short chord detections are folded into stable timeline segments instead of creating holes.
- Metronome reuses/releases its ToneGenerator instead of leaking one per click.
- Tuner fundamental estimation uses testable YIN-based PitchMath and exposes an A4 430–450 Hz reference control.
- Transition trainer shows the chord shapes actually played with the suggested capo while still opening the correct source-song A/B loop.
- Owner activation is available from Settings and must verify against the control server; there is no hard-coded manager password in the APK.
- Admin/Owner duties are separated: only Owner controls APK/release/forced-update metadata.
- Update downloads use HTTPS, optionally verify the Owner-published SHA-256, and only then hand the APK to Android's package installer.
- GitHub CI runs the control-server security test before Android compilation and emits an APK SHA-256 alongside the APK.

## Remaining blocker before device test

This execution environment does not contain the Android SDK/Gradle distribution and outbound package downloads are blocked, so it cannot compile the APK locally. Replit has been requested as a temporary external build path but has not returned an installable artifact. The included GitHub Actions workflow is the independent build path once a GitHub repository is connected.

The next device-test milestone is an actual `ChordFlow-beta.apk`; the project is not being represented as finished until that artifact has been compiled and installed on a real Android device.
